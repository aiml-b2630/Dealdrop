/**
 * DealDrop Hyperlocal REST API Server
 * Remediates Attempt #4 System Design & Security Gaps:
 * - Server-side state persistence
 * - Server-relative timestamp expiration calculation
 * - Dynamic Campaign Analytics aggregation
 * - Input validation & sanitization
 * - Voucher anti-hoarding 2-hour claim expiry logic
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Load initial data store
let dealsStore = [];
const dataPath = path.join(__dirname, 'deals.json');

try {
  const rawData = fs.readFileSync(dataPath, 'utf8');
  dealsStore = JSON.parse(rawData);
  
  // Attach server-relative expiry timestamps
  const now = Date.now();
  dealsStore.forEach(deal => {
    deal.targetTimestamp = now + (deal.expiryHours * 3600 * 1000);
    deal.claims = deal.claims || [];
  });
} catch (err) {
  console.error("Error reading deals.json:", err);
}

// In-memory claims ledger for anti-hoarding (2-hour expiry)
let claimsLedger = [];

// Helper: Sanitize string inputs against XSS
function sanitizeInput(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[<>'"&]/g, (char) => {
    const map = { '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;', '&': '&amp;' };
    return map[char];
  }).trim();
}

// GET /api/deals - Fetch active deals with optional category and radius query
app.get('/api/deals', (req, res) => {
  const { category, maxDistanceKm } = req.query;
  const now = Date.now();

  // Housekeeping: release expired unredeemed vouchers back to pool (2-hour limit)
  claimsLedger = claimsLedger.filter(claim => {
    if (claim.status === 'claimed' && (now - claim.claimedAt > 2 * 3600 * 1000)) {
      const deal = dealsStore.find(d => d.id === claim.dealId);
      if (deal && deal.claimedVouchers > 0) {
        deal.claimedVouchers -= 1;
      }
      return false; // Expired claim removed
    }
    return true;
  });

  let results = dealsStore.filter(d => d.targetTimestamp > now);

  if (category && category !== 'All') {
    results = results.filter(d => d.category.toLowerCase() === category.toLowerCase());
  }

  if (maxDistanceKm) {
    const radius = parseFloat(maxDistanceKm);
    if (!isNaN(radius)) {
      results = results.filter(d => d.distanceKm <= radius);
    }
  }

  res.json({
    success: true,
    serverTimestamp: now,
    count: results.length,
    deals: results
  });
});

// POST /api/deals/:id/claim - Server-validated deal redemption
app.get('/api/deals/:id/view', (req, res) => {
  const deal = dealsStore.find(d => d.id === req.params.id);
  if (deal) {
    deal.viewsCount = (deal.viewsCount || 0) + 1;
    return res.json({ success: true, viewsCount: deal.viewsCount });
  }
  res.status(404).json({ success: false, error: 'Deal not found' });
});

app.post('/api/deals/:id/claim', (req, res) => {
  const dealId = req.params.id;
  const deal = dealsStore.find(d => d.id === dealId);

  if (!deal) {
    return res.status(404).json({ success: false, error: 'Deal not found' });
  }

  if (deal.claimedVouchers >= deal.totalVouchers) {
    return res.status(400).json({ success: false, error: 'Voucher quota depleted for this flash offer' });
  }

  if (Date.now() > deal.targetTimestamp) {
    return res.status(400).json({ success: false, error: 'Flash deal has expired' });
  }

  // Increment server quota
  deal.claimedVouchers += 1;
  const voucherCode = `${deal.code}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
  const now = Date.now();

  claimsLedger.push({
    claimId: 'CLM-' + Date.now(),
    dealId: deal.id,
    voucherCode,
    claimedAt: now,
    status: 'claimed',
    expiresAt: now + (2 * 3600 * 1000) // 2-hour claim window
  });

  res.json({
    success: true,
    message: 'Voucher claimed successfully!',
    voucherCode,
    remainingVouchers: deal.totalVouchers - deal.claimedVouchers,
    claimExpiresAt: now + (2 * 3600 * 1000)
  });
});

// POST /api/deals - Merchant deal creation with strict input validation
app.post('/api/deals', (req, res) => {
  const { title, merchant, category, district, distanceKm, discountPercent, originalPrice, totalVouchers, expiryHours, description } = req.body;

  // Validation
  const cleanTitle = sanitizeInput(title);
  const cleanMerchant = sanitizeInput(merchant);
  const cleanCategory = sanitizeInput(category) || 'Dining';
  const cleanDistrict = sanitizeInput(district) || 'Downtown Metro';

  if (!cleanTitle || cleanTitle.length < 3) {
    return res.status(400).json({ success: false, error: 'Title must be at least 3 characters long' });
  }
  if (!cleanMerchant) {
    return res.status(400).json({ success: false, error: 'Merchant name is required' });
  }

  const dist = parseFloat(distanceKm);
  const discount = parseInt(discountPercent);
  const price = parseFloat(originalPrice);
  const vouchers = parseInt(totalVouchers);
  const hours = parseFloat(expiryHours) || 2;

  if (isNaN(dist) || dist <= 0) return res.status(400).json({ success: false, error: 'Invalid distance radius' });
  if (isNaN(discount) || discount < 1 || discount > 99) return res.status(400).json({ success: false, error: 'Discount percent must be between 1 and 99' });
  if (isNaN(price) || price <= 0) return res.status(400).json({ success: false, error: 'Invalid original price' });
  if (isNaN(vouchers) || vouchers < 1) return res.status(400).json({ success: false, error: 'Voucher quantity must be at least 1' });

  const discountedPrice = Math.round(price * (1 - (discount / 100)));
  const codePrefix = cleanMerchant.replace(/\s+/g, '').substring(0, 5).toUpperCase();
  const now = Date.now();

  const newDeal = {
    id: `deal-${Date.now()}`,
    title: cleanTitle,
    merchant: cleanMerchant,
    category: cleanCategory,
    district: cleanDistrict,
    distanceKm: dist,
    discountPercent: discount,
    originalPrice: price,
    discountedPrice,
    totalVouchers: vouchers,
    claimedVouchers: 0,
    viewsCount: 1,
    expiryHours: hours,
    targetTimestamp: now + (hours * 3600 * 1000),
    isHappyHour: discount >= 40,
    code: `${codePrefix}${discount}`,
    description: sanitizeInput(description) || 'Flash offer published by merchant.'
  };

  dealsStore.unshift(newDeal);

  res.status(201).json({
    success: true,
    message: 'Flash deal published successfully!',
    deal: newDeal
  });
});

// GET /api/analytics - Real-time Merchant Campaign Analytics Engine
app.get('/api/analytics', (req, res) => {
  let totalViews = 0;
  let totalClaims = 0;
  let totalVouchersAvailable = 0;
  let totalEstimatedSavings = 0;

  dealsStore.forEach(d => {
    totalViews += (d.viewsCount || 0);
    totalClaims += (d.claimedVouchers || 0);
    totalVouchersAvailable += d.totalVouchers;
    totalEstimatedSavings += (d.claimedVouchers * (d.originalPrice - d.discountedPrice));
  });

  const conversionRate = totalViews > 0 ? ((totalClaims / totalViews) * 100).toFixed(1) : 0;

  res.json({
    success: true,
    analytics: {
      activeDealsCount: dealsStore.length,
      totalViews,
      totalClaims,
      totalVouchersAvailable,
      conversionRate: `${conversionRate}%`,
      estimatedCustomerSavings: `₹${totalEstimatedSavings.toLocaleString()}`,
      estimatedWalkIns: Math.round(totalClaims * 0.85) // 85% conversion estimate
    }
  });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`DealDrop Server running on http://localhost:${PORT}`);
  });
}

module.exports = app;
