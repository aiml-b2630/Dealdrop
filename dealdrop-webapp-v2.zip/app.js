/**
 * DealDrop Browser Application Driver (Remediated Attempt #4)
 * Handles:
 * - Dynamic Campaign Analytics recalculation
 * - Real-time countdown timer loop
 * - Server API integration with LocalStorage fallback
 * - Anti-hoarding 2-hour voucher expiry timer
 * - Interactive QR Code Modal & Clipboard Copy
 */

class DealApp {
  constructor() {
    this.deals = [];
    this.activeCategory = 'All';
    this.activeRadius = 5;
    this.timerInterval = null;
    this.init();
  }

  async init() {
    this.bindEvents();
    await this.fetchDeals();
    this.startCountdownLoop();
    await this.refreshAnalytics();
  }

  bindEvents() {
    // Category tabs
    document.querySelectorAll('.cat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.activeCategory = btn.dataset.category;
        this.renderDeals();
      });
    });

    // Distance Radius Slider
    const radiusSlider = document.getElementById('radiusSlider');
    const radiusVal = document.getElementById('radiusValue');
    if (radiusSlider) {
      radiusSlider.addEventListener('input', (e) => {
        this.activeRadius = parseFloat(e.target.value);
        radiusVal.textContent = `${this.activeRadius} km`;
        this.renderDeals();
      });
    }

    // Merchant Modal Toggle
    const openBtn = document.getElementById('openMerchantModal');
    const closeBtn = document.getElementById('closeMerchantModal');
    const modal = document.getElementById('merchantModal');

    if (openBtn && modal) openBtn.addEventListener('click', () => modal.classList.add('visible'));
    if (closeBtn && modal) closeBtn.addEventListener('click', () => modal.classList.remove('visible'));

    // Merchant Form Submit
    const form = document.getElementById('createDealForm');
    if (form) {
      form.addEventListener('submit', (e) => this.handleCreateDeal(e));
    }

    // Modal close outside click
    window.addEventListener('click', (e) => {
      const voucherModal = document.getElementById('voucherModal');
      if (e.target === voucherModal) voucherModal.classList.remove('visible');
      if (e.target === modal) modal.classList.remove('visible');
    });
  }

  async fetchDeals() {
    try {
      const res = await fetch('/api/deals');
      if (res.ok) {
        const data = await res.json();
        this.deals = data.deals;
      } else {
        throw new Error('Server API unavailable');
      }
    } catch (err) {
      console.warn('Falling back to local data store:', err);
      // Fallback local dataset
      const local = localStorage.getItem('dealdrop_deals');
      if (local) {
        this.deals = JSON.parse(local);
      } else {
        this.deals = [
          {
            id: 'deal-1',
            title: '40% Off Artisan Coffee & Pastry',
            merchant: 'Bean & Bloom Cafe',
            category: 'Dining',
            district: 'Downtown Metro',
            distanceKm: 0.8,
            discountPercent: 40,
            originalPrice: 450,
            discountedPrice: 270,
            totalVouchers: 25,
            claimedVouchers: 17,
            viewsCount: 142,
            expiryHours: 2,
            targetTimestamp: Date.now() + (2 * 3600 * 1000),
            isHappyHour: true,
            code: 'BEAN40',
            description: 'Spontaneous off-peak afternoon coffee combo.'
          },
          {
            id: 'deal-2',
            title: '1+1 Free Gym Day Pass',
            merchant: 'Pulse Fitness Hub',
            category: 'Fitness',
            district: 'Greenwood District',
            distanceKm: 1.4,
            discountPercent: 50,
            originalPrice: 600,
            discountedPrice: 300,
            totalVouchers: 15,
            claimedVouchers: 11,
            viewsCount: 89,
            expiryHours: 4,
            targetTimestamp: Date.now() + (4 * 3600 * 1000),
            isHappyHour: false,
            code: 'PULSEBOGO',
            description: 'Bring a workout partner for free.'
          }
        ];
      }
    }
    this.renderDeals();
  }

  async refreshAnalytics() {
    try {
      const res = await fetch('/api/analytics');
      if (res.ok) {
        const data = await res.json();
        const a = data.analytics;
        document.getElementById('statTotalViews').textContent = a.totalViews;
        document.getElementById('statTotalClaims').textContent = a.totalClaims;
        document.getElementById('statConversion').textContent = a.conversionRate;
        document.getElementById('statWalkIns').textContent = a.estimatedWalkIns;
        document.getElementById('statSavings').textContent = a.estimatedCustomerSavings;
        return;
      }
    } catch (e) {
      // Local calculation fallback
    }

    let views = 0, claims = 0, savings = 0;
    this.deals.forEach(d => {
      views += (d.viewsCount || 0);
      claims += d.claimedVouchers;
      savings += (d.claimedVouchers * (d.originalPrice - d.discountedPrice));
    });
    const conv = views > 0 ? ((claims / views) * 100).toFixed(1) : '0.0';

    document.getElementById('statTotalViews').textContent = views;
    document.getElementById('statTotalClaims').textContent = claims;
    document.getElementById('statConversion').textContent = `${conv}%`;
    document.getElementById('statWalkIns').textContent = Math.round(claims * 0.85);
    document.getElementById('statSavings').textContent = `₹${savings.toLocaleString()}`;
  }

  renderDeals() {
    const grid = document.getElementById('dealsGrid');
    if (!grid) return;

    const filtered = this.deals.filter(d => {
      const matchCat = (this.activeCategory === 'All' || d.category.toLowerCase() === this.activeCategory.toLowerCase());
      const matchDist = d.distanceKm <= this.activeRadius;
      return matchCat && matchDist;
    });

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <p>No active deals found within ${this.activeRadius} km for category "${this.activeCategory}".</p>
          <button class="btn-primary" onclick="app.resetFilters()">Reset Filters</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(deal => {
      const remaining = deal.totalVouchers - deal.claimedVouchers;
      const progressPercent = Math.round((deal.claimedVouchers / deal.totalVouchers) * 100);

      return `
        <div class="deal-card ${deal.isHappyHour ? 'happy-hour-card' : ''}">
          ${deal.isHappyHour ? '<span class="badge happy-hour-badge">⚡ Happy Hour 30%+</span>' : ''}
          <div class="card-header">
            <span class="category-tag">${deal.category}</span>
            <span class="distance-tag">📍 ${deal.distanceKm} km away</span>
          </div>
          <h3 class="deal-title">${deal.title}</h3>
          <p class="merchant-name">By ${deal.merchant} • <span class="district">${deal.district}</span></p>

          <div class="price-row">
            <span class="discount-badge">${deal.discountPercent}% OFF</span>
            <span class="discounted-price">₹${deal.discountedPrice}</span>
            <span class="original-price">₹${deal.originalPrice}</span>
          </div>

          <div class="timer-container" id="timer-${deal.id}">
            ⏱️ Expires in: <span class="timer-clock">Calculating...</span>
          </div>

          <div class="quota-container">
            <div class="quota-text">
              <span>Remaining: <strong>${remaining} of ${deal.totalVouchers}</strong></span>
              <span>${progressPercent}% claimed</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${progressPercent}%;"></div>
            </div>
          </div>

          <button class="btn-claim ${remaining <= 0 ? 'disabled' : ''}" 
                  onclick="app.claimVoucher('${deal.id}')" ${remaining <= 0 ? 'disabled' : ''}>
            ${remaining > 0 ? '⚡ Claim Discount Voucher' : 'Sold Out'}
          </button>
        </div>
      `;
    }).join('');

    this.updateCountdowns();
  }

  resetFilters() {
    this.activeCategory = 'All';
    this.activeRadius = 5;
    document.getElementById('radiusSlider').value = 5;
    document.getElementById('radiusValue').textContent = '5 km';
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.cat-btn[data-category="All"]').classList.add('active');
    this.renderDeals();
  }

  startCountdownLoop() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => this.updateCountdowns(), 1000);
  }

  updateCountdowns() {
    const now = Date.now();

    this.deals.forEach(deal => {
      const timerEl = document.getElementById(`timer-${deal.id}`);
      if (!timerEl) return;

      const diff = deal.targetTimestamp - now;
      if (diff <= 0) {
        timerEl.innerHTML = '<span class="expired-label">❌ Deal Expired</span>';
        return;
      }

      const h = Math.floor(diff / (1000 * 3600));
      const m = Math.floor((diff % (1000 * 3600)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      const clockStr = `${h}h ${m < 10 ? '0'+m : m}m ${s < 10 ? '0'+s : s}s`;
      const isUrgent = diff < (3600 * 1000);

      const clockSpan = timerEl.querySelector('.timer-clock');
      if (clockSpan) {
        clockSpan.textContent = clockStr;
        if (isUrgent) {
          timerEl.classList.add('urgent');
        }
      }
    });
  }

  async claimVoucher(dealId) {
    // Increment view count endpoint
    fetch(`/api/deals/${dealId}/view`).catch(() => {});

    try {
      const res = await fetch(`/api/deals/${dealId}/claim`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        const deal = this.deals.find(d => d.id === dealId);
        if (deal) deal.claimedVouchers += 1;
        this.showVoucherModal(data.voucherCode, deal);
        this.renderDeals();
        this.refreshAnalytics();
        return;
      }
    } catch (e) {
      console.warn('Backend claim failed, processing local claim');
    }

    // Local Fallback claim
    const deal = this.deals.find(d => d.id === dealId);
    if (deal && deal.claimedVouchers < deal.totalVouchers) {
      deal.claimedVouchers += 1;
      const code = `${deal.code}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      localStorage.setItem('dealdrop_deals', JSON.stringify(this.deals));
      this.showVoucherModal(code, deal);
      this.renderDeals();
      this.refreshAnalytics();
    }
  }

  showVoucherModal(voucherCode, deal) {
    const modal = document.getElementById('voucherModal');
    if (!modal) return;

    document.getElementById('voucherCodeDisplay').textContent = voucherCode;
    document.getElementById('voucherDealTitle').textContent = deal.title;
    document.getElementById('voucherMerchantName').textContent = deal.merchant;

    // Simulated anti-hoarding 2-hour expiry clock
    const expiresAt = new Date(Date.now() + (2 * 3600 * 1000)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    document.getElementById('voucherExpiryNotice').textContent = `⚠️ Redeem in-store before ${expiresAt} (2-hour claim window).`;

    modal.classList.add('visible');
  }

  async copyVoucherCode() {
    const code = document.getElementById('voucherCodeDisplay').textContent;
    try {
      await navigator.clipboard.writeText(code);
      this.showToast('✅ Voucher code copied to clipboard!');
    } catch (err) {
      this.showToast(`Code: ${code}`);
    }
  }

  async handleCreateDeal(e) {
    e.preventDefault();

    const title = document.getElementById('dealTitleInput').value.trim();
    const merchant = document.getElementById('merchantNameInput').value.trim();
    const category = document.getElementById('categoryInput').value;
    const distanceKm = parseFloat(document.getElementById('distanceInput').value);
    const discountPercent = parseInt(document.getElementById('discountInput').value);
    const originalPrice = parseFloat(document.getElementById('priceInput').value);
    const totalVouchers = parseInt(document.getElementById('quotaInput').value);
    const expiryHours = parseFloat(document.getElementById('expiryInput').value) || 2;

    if (!title || !merchant || isNaN(discountPercent) || isNaN(originalPrice) || isNaN(totalVouchers)) {
      alert('Please fill out all required fields correctly.');
      return;
    }

    const newDealPayload = {
      title, merchant, category, district: 'Neighborhood', distanceKm,
      discountPercent, originalPrice, totalVouchers, expiryHours,
      description: 'Newly published flash deal'
    };

    try {
      const res = await fetch('/api/deals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newDealPayload)
      });

      if (res.ok) {
        const data = await res.json();
        this.deals.unshift(data.deal);
        this.showToast('🚀 Flash Deal Published in under 30 seconds!');
      } else {
        throw new Error('Server error');
      }
    } catch (err) {
      // Local fallback
      const newDeal = {
        id: `deal-${Date.now()}`,
        ...newDealPayload,
        discountedPrice: Math.round(originalPrice * (1 - (discountPercent / 100))),
        claimedVouchers: 0,
        viewsCount: 1,
        targetTimestamp: Date.now() + (expiryHours * 3600 * 1000),
        isHappyHour: discountPercent >= 40,
        code: `${merchant.substring(0, 4).toUpperCase()}${discountPercent}`
      };
      this.deals.unshift(newDeal);
      localStorage.setItem('dealdrop_deals', JSON.stringify(this.deals));
      this.showToast('⚡ Deal published locally!');
    }

    document.getElementById('merchantModal').classList.remove('visible');
    document.getElementById('createDealForm').reset();
    this.renderDeals();
    this.refreshAnalytics();
  }

  showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 50);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
}

let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new DealApp();
});
