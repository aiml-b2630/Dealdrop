/**
 * DealDrop Frontend Core Engine (TypeScript)
 * Modular Architecture with separation of concerns:
 * - DealEngine (Filtering, distance Heuristics)
 * - AnalyticsEngine (Live campaign calculation)
 * - ValidationService (XSS Sanitization & Input Checks)
 * - VoucherManager (Clipboard & 2-Hour Expiry Pool)
 */

export interface Deal {
  id: string;
  title: string;
  merchant: string;
  category: 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';
  district: string;
  distanceKm: number;
  discountPercent: number;
  originalPrice: number;
  discountedPrice: number;
  totalVouchers: number;
  claimedVouchers: number;
  viewsCount: number;
  expiryHours: number;
  targetTimestamp: number;
  isHappyHour?: boolean;
  code: string;
  description: string;
}

export interface AnalyticsSummary {
  activeDealsCount: number;
  totalViews: number;
  totalClaims: number;
  conversionRate: string;
  estimatedCustomerSavings: string;
  estimatedWalkIns: number;
}

export class ValidationService {
  static sanitize(str: string): string {
    if (!str) return '';
    const div = document.createElement('div');
    div.innerText = str;
    return div.innerHTML;
  }

  static validateMerchantInput(title: string, merchant: string, discount: number, price: number, vouchers: number): string | null {
    if (!title || title.trim().length < 3) return 'Title must be at least 3 characters.';
    if (!merchant || merchant.trim().length < 2) return 'Merchant name is required.';
    if (isNaN(discount) || discount < 1 || discount > 99) return 'Discount must be between 1% and 99%.';
    if (isNaN(price) || price <= 0) return 'Price must be greater than 0.';
    if (isNaN(vouchers) || vouchers < 1) return 'Vouchers must be at least 1.';
    return null;
  }
}

export class DealEngine {
  private deals: Deal[] = [];

  constructor(initialDeals: Deal[] = []) {
    this.deals = initialDeals;
  }

  public setDeals(deals: Deal[]): void {
    this.deals = deals;
  }

  public filterDeals(category: string, maxRadiusKm: number): Deal[] {
    return this.deals.filter(deal => {
      const matchCategory = (category === 'All' || deal.category.toLowerCase() === category.toLowerCase());
      const matchDistance = deal.distanceKm <= maxRadiusKm;
      return matchCategory && matchDistance;
    });
  }

  public calculateTimeRemaining(targetTimestamp: number): { hours: number; minutes: number; seconds: number; isExpired: boolean; isUrgent: boolean } {
    const now = Date.now();
    const diff = targetTimestamp - now;

    if (diff <= 0) {
      return { hours: 0, minutes: 0, seconds: 0, isExpired: true, isUrgent: false };
    }

    const hours = Math.floor(diff / (1000 * 3600));
    const minutes = Math.floor((diff % (1000 * 3600)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    const isUrgent = diff < (3600 * 1000); // Less than 1 hour remaining

    return { hours, minutes, seconds, isExpired: false, isUrgent };
  }

  public getHappyHourDeals(): Deal[] {
    return this.deals.filter(d => d.isHappyHour || d.discountPercent >= 40);
  }
}
