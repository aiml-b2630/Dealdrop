// DealDrop Core TypeScript Application Architecture
export interface Deal {
    id: string;
    title: string;
    merchantName: string;
    category: 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';
    district: string;
    distanceKm: number;
    originalPrice: number;
    discountedPrice: number;
    discountPercent: number;
    promoCode: string;
    totalQuota: number;
    claimedCount: number;
    expiryMinutes: number;
    isHappyHour: boolean;
    description: string;
    rating: number;
    targetExpiryTimestamp?: number;
}

export class DealDropApp {
    private deals: Deal[] = [];
    private activeCategory: string = 'All';
    private maxDistance: number = 3; // km
    private searchQuery: string = '';
    private happyHourOnly: boolean = false;
    private sortBy: 'expiry' | 'distance' | 'discount' = 'expiry';
    private userClaimedVouchers: string[] = [];

    constructor() {
        this.init();
    }

    private async init() {
        await this.loadDeals();
        this.loadLocalStorage();
        this.setupEventListeners();
        this.render();
        this.startCountdownTimer();
    }

    private async loadDeals() {
        try {
            const res = await fetch('deals.json');
            const data: Deal[] = await res.json();
            const now = Date.now();
            this.deals = data.map(d => ({
                ...d,
                targetExpiryTimestamp: now + (d.expiryMinutes * 60 * 1000)
            }));
        } catch (err) {
            console.error('Failed to fetch deals dataset:', err);
        }
    }

    private loadLocalStorage() {
        const saved = localStorage.getItem('dealdrop_claimed');
        if (saved) {
            this.userClaimedVouchers = JSON.parse(saved);
        }
        this.updateClaimedCounter();
    }

    private setupEventListeners() {
        // Search
        const searchInput = document.getElementById('search-input') as HTMLInputElement;
        searchInput?.addEventListener('input', (e) => {
            this.searchQuery = (e.target as HTMLInputElement).value.toLowerCase();
            this.render();
        });

        // Distance Select
        const radiusSelect = document.getElementById('radius-select') as HTMLSelectElement;
        radiusSelect?.addEventListener('change', (e) => {
            const val = (e.target as HTMLSelectElement).value;
            this.maxDistance = val === 'all' ? 999 : parseFloat(val);
            this.render();
        });

        // Category Tabs
        const categoryTabs = document.getElementById('category-tabs');
        categoryTabs?.addEventListener('click', (e) => {
            const target = (e.target as HTMLElement).closest('.tab-btn') as HTMLElement;
            if (target) {
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                target.classList.add('active');
                this.activeCategory = target.dataset.category || 'All';
                this.render();
            }
        });

        // Happy Hour Toggle
        const happyHourToggle = document.getElementById('happy-hour-only') as HTMLInputElement;
        happyHourToggle?.addEventListener('change', (e) => {
            this.happyHourOnly = (e.target as HTMLInputElement).checked;
            this.render();
        });

        // Sort Select
        const sortSelect = document.getElementById('sort-select') as HTMLSelectElement;
        sortSelect?.addEventListener('change', (e) => {
            this.sortBy = (e.target as HTMLSelectElement).value as any;
            this.render();
        });

        // Merchant Cockpit Modal
        const openMerchantBtn = document.getElementById('open-merchant-btn');
        const closeMerchantBtn = document.getElementById('close-merchant-btn');
        const merchantModal = document.getElementById('merchant-modal');

        openMerchantBtn?.addEventListener('click', () => merchantModal?.classList.add('active'));
        closeMerchantBtn?.addEventListener('click', () => merchantModal?.classList.remove('active'));

        // Merchant Form Submit
        const merchantForm = document.getElementById('merchant-form') as HTMLFormElement;
        merchantForm?.addEventListener('submit', (e) => this.handleMerchantPublish(e));

        // Voucher Modal Close
        const closeVoucherBtn = document.getElementById('close-voucher-btn');
        const voucherModal = document.getElementById('voucher-modal');
        closeVoucherBtn?.addEventListener('click', () => voucherModal?.classList.remove('active'));
    }

    private handleMerchantPublish(e: Event) {
        e.preventDefault();
        const now = Date.now();
        const expiryMins = parseInt((document.getElementById('m-expiry') as HTMLInputElement).value);
        
        const newDeal: Deal = {
            id: 'deal-' + (this.deals.length + 1),
            merchantName: (document.getElementById('m-name') as HTMLInputElement).value,
            category: (document.getElementById('m-category') as HTMLSelectElement).value as any,
            district: (document.getElementById('m-district') as HTMLInputElement).value,
            title: (document.getElementById('m-title') as HTMLInputElement).value,
            originalPrice: parseFloat((document.getElementById('m-orig-price') as HTMLInputElement).value),
            discountedPrice: parseFloat((document.getElementById('m-disc-price') as HTMLInputElement).value),
            discountPercent: Math.round((1 - (parseFloat((document.getElementById('m-disc-price') as HTMLInputElement).value) / parseFloat((document.getElementById('m-orig-price') as HTMLInputElement).value))) * 100),
            promoCode: (document.getElementById('m-code') as HTMLInputElement).value.toUpperCase(),
            totalQuota: parseInt((document.getElementById('m-quota') as HTMLInputElement).value),
            claimedCount: 0,
            expiryMinutes: expiryMins,
            distanceKm: parseFloat((document.getElementById('m-distance') as HTMLInputElement).value),
            isHappyHour: true,
            description: "Merchant published flash offer.",
            rating: 5.0,
            targetExpiryTimestamp: now + (expiryMins * 60 * 1000)
        };

        this.deals.unshift(newDeal);
        this.render();
        
        document.getElementById('merchant-modal')?.classList.remove('active');
        (document.getElementById('merchant-form') as HTMLFormElement).reset();
        this.showToast('Deal published successfully live to nearby shoppers!');
    }

    private filterAndSortDeals(): Deal[] {
        return this.deals.filter(d => {
            const matchesCat = this.activeCategory === 'All' || d.category === this.activeCategory;
            const matchesDist = d.distanceKm <= this.maxDistance;
            const matchesSearch = d.title.toLowerCase().includes(this.searchQuery) || 
                                  d.merchantName.toLowerCase().includes(this.searchQuery) ||
                                  d.district.toLowerCase().includes(this.searchQuery);
            const matchesHappy = !this.happyHourOnly || d.isHappyHour;
            return matchesCat && matchesDist && matchesSearch && matchesHappy;
        }).sort((a, b) => {
            if (this.sortBy === 'expiry') {
                return (a.targetExpiryTimestamp || 0) - (b.targetExpiryTimestamp || 0);
            } else if (this.sortBy === 'distance') {
                return a.distanceKm - b.distanceKm;
            } else {
                return b.discountPercent - a.discountPercent;
            }
        });
    }

    private render() {
        const grid = document.getElementById('deals-grid');
        const resultsCount = document.getElementById('results-count');
        const filtered = this.filterAndSortDeals();

        if (resultsCount) {
            resultsCount.textContent = `Showing ${filtered.length} deals nearby`;
        }

        if (!grid) return;
        grid.innerHTML = '';

        if (filtered.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #64748b;">
                    <h3>No matching deals found</h3>
                    <p>Try widening your distance radius or clearing filters.</p>
                </div>
            `;
            return;
        }

        filtered.forEach(deal => {
            const card = document.createElement('div');
            card.className = 'deal-card';

            const remainingQuota = deal.totalQuota - deal.claimedCount;
            const quotaPercent = Math.round((deal.claimedCount / deal.totalQuota) * 100);

            card.innerHTML = `
                <div class="card-header">
                    <div class="card-badges">
                        <span class="category-tag">${deal.category}</span>
                        ${deal.isHappyHour ? '<span class="happy-hour-badge"><i data-lucide="zap"></i> Happy Hour</span>' : ''}
                    </div>
                    <h3 class="card-title">${deal.title}</h3>
                    <div class="merchant-row">
                        <span class="merchant-name">${deal.merchantName}</span>
                        <span><i data-lucide="map-pin" style="width:14px;height:14px;display:inline;"></i> ${deal.district} (${deal.distanceKm} km)</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="price-row">
                        <span class="disc-price">$${deal.discountedPrice.toFixed(2)}</span>
                        <span class="orig-price">$${deal.originalPrice.toFixed(2)}</span>
                        <span class="discount-badge">${deal.discountPercent}% OFF</span>
                    </div>

                    <div class="expiry-box" data-expiry-ts="${deal.targetExpiryTimestamp}">
                        <i data-lucide="clock" style="width:16px;height:16px;"></i>
                        <span class="expiry-timer-text">Calculating timer...</span>
                    </div>

                    <div class="quota-container">
                        <div class="quota-header">
                            <span>Vouchers Left</span>
                            <span>${remainingQuota} of ${deal.totalQuota} left</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${quotaPercent}%"></div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn code-btn copy-code-btn" data-code="${deal.promoCode}">
                        <i data-lucide="copy" style="width:16px;height:16px;"></i> ${deal.promoCode}
                    </button>
                    <button class="btn btn-primary claim-deal-btn" data-id="${deal.id}">
                        <i data-lucide="ticket" style="width:16px;height:16px;"></i> Claim
                    </button>
                </div>
            `;

            grid.appendChild(card);
        });

        // Re-initialize Lucide Icons
        if ((window as any).lucide) {
            (window as any).lucide.createIcons();
        }

        this.bindCardActions();
        this.updateTimers();
    }

    private bindCardActions() {
        document.querySelectorAll('.copy-code-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const code = (e.currentTarget as HTMLElement).dataset.code || '';
                navigator.clipboard.writeText(code);
                this.showToast(`Promo code '${code}' copied to clipboard!`);
            });
        });

        document.querySelectorAll('.claim-deal-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = (e.currentTarget as HTMLElement).dataset.id;
                const deal = this.deals.find(d => d.id === id);
                if (deal) {
                    this.claimVoucher(deal);
                }
            });
        });
    }

    private claimVoucher(deal: Deal) {
        if (deal.claimedCount < deal.totalQuota) {
            deal.claimedCount++;
        }

        if (!this.userClaimedVouchers.includes(deal.id)) {
            this.userClaimedVouchers.push(deal.id);
            localStorage.setItem('dealdrop_claimed', JSON.stringify(this.userClaimedVouchers));
        }

        this.updateClaimedCounter();
        this.render();

        // Populate and open voucher modal
        (document.getElementById('v-modal-shop')!).textContent = deal.merchantName;
        (document.getElementById('v-modal-title')!).textContent = deal.title;
        (document.getElementById('v-modal-code')!).textContent = deal.promoCode;
        (document.getElementById('v-modal-district')!).textContent = `${deal.district} (${deal.distanceKm} km)`;
        
        document.getElementById('voucher-modal')?.classList.add('active');
        this.showToast(`Voucher claimed! Present QR code to cashier.`);
    }

    private updateClaimedCounter() {
        const el = document.getElementById('user-claimed-count');
        if (el) el.textContent = this.userClaimedVouchers.length.toString();
    }

    private startCountdownTimer() {
        setInterval(() => this.updateTimers(), 1000);
    }

    private updateTimers() {
        const now = Date.now();
        document.querySelectorAll('.expiry-box').forEach(box => {
            const ts = parseInt((box as HTMLElement).dataset.expiryTs || '0');
            const timerText = box.querySelector('.expiry-timer-text');
            const diff = ts - now;

            if (diff <= 0) {
                if (timerText) timerText.textContent = 'Deal Expired';
                box.classList.remove('urgent');
            } else {
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                const secs = Math.floor((diff % (1000 * 60)) / 1000);
                
                if (timerText) {
                    timerText.textContent = `Ends in ${hours}h ${mins}m ${secs}s`;
                }

                if (hours === 0 && mins < 60) {
                    box.classList.add('urgent');
                } else {
                    box.classList.remove('urgent');
                }
            }
        });
    }

    private showToast(message: string) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `<i data-lucide="check-circle" style="width:18px;height:18px;color:#10b981;"></i> ${message}`;
        container.appendChild(toast);

        if ((window as any).lucide) {
            (window as any).lucide.createIcons();
        }

        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
}

// Instantiate on DOM load
window.addEventListener('DOMContentLoaded', () => {
    new DealDropApp();
});
