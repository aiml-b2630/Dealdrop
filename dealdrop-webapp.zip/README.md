# DealDrop — Hyperlocal Flash Deals & Coupon Portal

DealDrop is a responsive retail & e-commerce deal discovery web application designed for brick-and-mortar neighborhood businesses to publish limited-time discounts and nearby residents to claim instant vouchers.

## 🚀 Key Features Implemented

### Modules 1–2: Static Layout & Design System (HTML/CSS)
- **Responsive Flexbox & Grid Layout**: Clean navigation, hero banner, category filters, and deal grid optimized across desktop, tablet, and mobile devices.
- **Category Taxonomy**: Dining, Wellness, Fitness, Entertainment, and Services.
- **Hyperlocal Distance Radius**: Proximity filtering (1 km, 3 km, 5 km, Any).
- **Modern Styling**: Dark navbar, vibrant primary accents (`#f97316`), responsive typography, and subtle micro-interactions.

### Modules 3–4: Dynamic Engine (TypeScript / JavaScript & Fetch API)
- **Typed Data Layer (`Deal` Interface & Fetch API)**: Asynchronous loading from `deals.json` containing 16 realistic neighborhood flash deals.
- **Real-Time Expiry Countdown Clock**: Live countdown timers (`Xh Ym Zs remaining`) updating every second, with animated urgency styling when under 60 minutes.
- **One-Click Code Copier**: Clipboard API integration with animated toast notification feedback.
- **Voucher Quota Cap & Claim Tracking**: Quota decrementing logic with progress bar visualizers and `localStorage` persistence.
- **Digital Voucher QR Modal**: Simulated barcode/QR modal for in-store cashier scanning.
- **Merchant Cockpit Dashboard**: Rapid deal publishing form (<60s creation flow) and merchant performance metrics (views, vouchers claimed, walk-in estimates).

## 📁 Package Architecture

```
dealdrop-webapp/
├── index.html       # Main HTML5 application structure
├── styles.css       # Complete modern responsive CSS stylesheet
├── app.ts           # Core TypeScript application logic & typed contracts
├── app.js           # Compiled JavaScript engine (browser-ready)
├── deals.json       # Pre-populated dataset of 16 flash deals
└── README.md        # Architecture & deployment guide
```

## 💻 How to Run

1. Unzip `dealdrop-webapp.zip`.
2. Open `index.html` in any web browser, or serve using a simple local HTTP server:
   ```bash
   npx serve .
   ```
3. Enjoy exploring DealDrop!
