// Structured JSON Logger
const fs = require('fs');
const path = require('path');
const logFile = path.join(__dirname, 'server.log');

function log(level, message, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    level: level.toUpperCase(),
    message,
    ...meta
  };

  const line = JSON.stringify(entry) + '\n';
  console.log(`[${entry.timestamp}] ${entry.level}: ${message}`);
  fs.appendFileSync(logFile, line, 'utf-8');
}

module.exports = {
  info: (msg, meta) => log('info', msg, meta),
  warn: (msg, meta) => log('warn', msg, meta),
  error: (msg, meta) => log('error', msg, meta)
};
