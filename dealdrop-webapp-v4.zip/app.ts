// DealDrop Core Business Logic Engine (Decoupled from DOM)
export interface Deal {
  id: string;
  title: string;
  category: 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';
  discount: number;
  code: string;
  quota: number;
  claimedCount: number;
  distanceKm: number;
  expiresInMinutes: number;
  expiryTimestamp: number;
  merchant: string;
  district: string;
  views?: number;
}

export class DealService {
  private deals: Deal[] = [];

  constructor(initialDeals: Deal[] = []) {
    this.deals = initialDeals;
  }

  public setDeals(deals: Deal[]): void {
    this.deals = deals;
  }

  public filterDeals(category: string, maxDistance: number): Deal[] {
    return this.deals.filter(deal => {
      const matchCategory = category === 'All' || deal.category === category;
      const matchDistance = deal.distanceKm <= maxDistance;
      return matchCategory && matchDistance;
    });
  }

  public calculateTimeRemaining(expiryTimestamp: number): { hours: number; minutes: number; seconds: number; isExpired: boolean; isUrgent: boolean } {
    const diff = expiryTimestamp - Date.now();
    if (diff <= 0) {
      return { hours: 0, minutes: 0, seconds: 0, isExpired: true, isUrgent: false };
    }
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    const isUrgent = diff <= 60 * 60 * 1000; // Under 1 hour
    return { hours, minutes, seconds, isExpired: false, isUrgent };
  }

  public isHappyHour(discount: number): boolean {
    const currentHour = new Date().getHours();
    return discount >= 40 && (currentHour >= 14 && currentHour <= 17); // 2-5 PM off-peak
  }
}
