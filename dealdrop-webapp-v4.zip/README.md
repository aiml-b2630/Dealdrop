# DealDrop — Hyperlocal Promotional Flash-Deal Platform (v4.0 Production Release)

DealDrop is a full-stack hyperlocal promotional web application designed for brick-and-mortar neighborhood merchants to publish spontaneous flash deals and for nearby consumers to claim instant discount vouchers.

## 🚀 Key Features & Architecture (v4.0 Remediation)

1. **Atomic SQLite Transactions (`db.js`, `server.js`)**:
   - Voucher claiming is executed inside explicit SQLite database transactions (`BEGIN IMMEDIATE` / `COMMIT`) to guarantee data integrity and prevent race conditions during high-concurrency voucher claims.

2. **Comprehensive API Payload Validation (`validator.js`)**:
   - Strict schema validation for all REST API endpoints. Validates types, ranges, enums (`Dining`, `Wellness`, `Fitness`, `Entertainment`, `Services`), string lengths, and numeric bounds. Returns structured `400 Bad Request` responses on invalid inputs.

3. **JWT Merchant Authentication (`auth.js`)**:
   - Protected endpoints require Bearer JWT authentication. Provides login modal (`admin` / `password123`) for merchant authorization.

4. **Decoupled Frontend Architecture (`app.ts` / `app.js`)**:
   - Clean separation of concerns: `DealService` handles business logic, distance calculations, countdown intervals, and state management completely decoupled from the DOM. `UIController` handles DOM events and view rendering.

5. **Expanded Integration & Unit Test Suite (`test/api.test.js`, `test/dealEngine.test.js`)**:
   - Suite covers core filtering heuristics, countdown urgency, unauthorized 401/403 access attempts, and 400 malformed input payload rejections.

6. **Structured Observability Logging (`logger.js`, `server.log`)**:
   - ISO-timestamped JSON logs for API requests, authentication attempts, database transactions, and system events.

## 🛠️ Quick Start

```bash
# Install dependencies (Node.js & Express / SQLite3 environment)
npm install

# Run automated test suite (Unit + API Integration tests)
npm test

# Start server
npm start
```
