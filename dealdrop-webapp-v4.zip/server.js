// Production Express REST API Backend for DealDrop v4.0
const express = require('express');
const cors = require('cors');
const path = require('path');
const { getQuery, allQuery, runQuery, claimVoucherTransaction } = require('./db');
const { generateToken, authMiddleware } = require('./auth');
const { validateDealPayload, sanitizeInput } = require('./validator');
const logger = require('./logger');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Public: Get all active deals
app.get('/api/deals', async (req, res) => {
  try {
    const deals = await allQuery('SELECT * FROM deals ORDER BY createdAt DESC');
    logger.info('Fetched deals directory', { count: deals.length });
    res.json(deals);
  } catch (err) {
    logger.error('Failed to fetch deals', { error: err.message });
    res.status(500).json({ error: 'Failed to retrieve deals' });
  }
});

// Public: Increment view count for deal analytics
app.post('/api/deals/:id/view', async (req, res) => {
  try {
    const { id } = req.params;
    await runQuery('UPDATE deals SET views = views + 1 WHERE id = ?', [id]);
    await runQuery('UPDATE analytics_summary SET totalViews = totalViews + 1 WHERE id = 1');
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'View tracking failed' });
  }
});

// Public: Claim a deal voucher using atomic SQLite Transaction
app.post('/api/deals/:id/claim', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await claimVoucherTransaction(id);
    if (!result.success) {
      return res.status(result.status).json({ error: result.message });
    }
    logger.info('Voucher claimed successfully', { dealId: id, claimId: result.claimId });
    res.json(result);
  } catch (err) {
    logger.error('Voucher claim error', { dealId: req.params.id, error: err.message });
    res.status(500).json({ error: 'Internal transaction error during voucher claim' });
  }
});

// Merchant Authentication Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'password123') {
    const token = generateToken('merchant_001');
    logger.info('Merchant login successful', { username });
    return res.json({ success: true, token });
  }
  logger.warn('Failed merchant login attempt', { username });
  res.status(401).json({ error: 'Invalid merchant credentials' });
});

// Protected: Publish a new deal (Requires JWT & Strict Validation)
app.post('/api/deals', authMiddleware, async (req, res) => {
  const validation = validateDealPayload(req.body);
  if (!validation.valid) {
    logger.warn('Rejected malformed deal creation request', { errors: validation.errors });
    return res.status(400).json({ error: 'Validation failed', details: validation.errors });
  }

  const { title, category, discount, quota, distanceKm, expiresInMinutes, merchant, district } = req.body;

  const sanitizedTitle = sanitizeInput(title);
  const sanitizedMerchant = sanitizeInput(merchant);
  const sanitizedDistrict = sanitizeInput(district || 'Central District');

  const id = 'deal-' + Math.random().toString(36).substr(2, 7);
  const code = (sanitizedCategory || category).substring(0, 3).toUpperCase() + discount + '-' + Math.floor(100 + Math.random() * 900);
  const now = Date.now();
  const expiryTimestamp = now + ((expiresInMinutes || 120) * 60 * 1000);

  try {
    await runQuery(`
      INSERT INTO deals (id, title, category, discount, code, quota, claimedCount, distanceKm, expiresInMinutes, expiryTimestamp, merchant, district, views, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, 0, ?)
    `, [id, sanitizedTitle, category, discount, code, quota, distanceKm, expiresInMinutes || 120, expiryTimestamp, sanitizedMerchant, sanitizedDistrict, now]);

    logger.info('Published new flash deal', { dealId: id, title: sanitizedTitle });
    res.status(201).json({
      id,
      title: sanitizedTitle,
      category,
      discount,
      code,
      quota,
      claimedCount: 0,
      distanceKm,
      expiresInMinutes: expiresInMinutes || 120,
      expiryTimestamp,
      merchant: sanitizedMerchant,
      district: sanitizedDistrict
    });
  } catch (err) {
    logger.error('Failed to create deal', { error: err.message });
    res.status(500).json({ error: 'Database error while creating deal' });
  }
});

// Public: Get aggregated analytics summary (O(1) query)
app.get('/api/analytics', async (req, res) => {
  try {
    const analytics = await getQuery('SELECT * FROM analytics_summary WHERE id = 1');
    res.json(analytics || { totalViews: 0, totalClaims: 0, estimatedWalkIns: 0, totalSavings: 0 });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

if (require.main === module) {
  app.listen(PORT, () => {
    logger.info(`DealDrop REST API running on port ${PORT}`);
  });
}

module.exports = app;
