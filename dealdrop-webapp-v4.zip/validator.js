// Strict Server-Side Payload Validation Service
const VALID_CATEGORIES = ['Dining', 'Wellness', 'Fitness', 'Entertainment', 'Services'];

function validateDealPayload(data) {
  const errors = [];

  if (!data.title || typeof data.title !== 'string' || data.title.trim().length < 3 || data.title.trim().length > 100) {
    errors.push('Title must be a string between 3 and 100 characters.');
  }

  if (!data.category || !VALID_CATEGORIES.includes(data.category)) {
    errors.push(`Category must be one of: ${VALID_CATEGORIES.join(', ')}.`);
  }

  if (typeof data.discount !== 'number' || !Number.isInteger(data.discount) || data.discount < 1 || data.discount > 100) {
    errors.push('Discount must be an integer percentage between 1 and 100.');
  }

  if (typeof data.quota !== 'number' || !Number.isInteger(data.quota) || data.quota < 1 || data.quota > 1000) {
    errors.push('Quota must be a positive integer between 1 and 1000.');
  }

  if (typeof data.distanceKm !== 'number' || data.distanceKm <= 0 || data.distanceKm > 50) {
    errors.push('Distance must be a positive number up to 50 km.');
  }

  if (!data.merchant || typeof data.merchant !== 'string' || data.merchant.trim().length < 2) {
    errors.push('Merchant name is required.');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

function sanitizeInput(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[<>'"]/g, '');
}

module.exports = {
  validateDealPayload,
  sanitizeInput,
  VALID_CATEGORIES
};
