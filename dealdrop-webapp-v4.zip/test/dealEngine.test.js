// Unit Test Suite for Deal Engine Logic
const assert = require('assert');

console.log('==========================================');
console.log(' Running Deal Engine Logic Tests (v4)     ');
console.log('==========================================');

class TestDealEngine {
  filterDeals(deals, category, maxDistance) {
    return deals.filter(d => (category === 'All' || d.category === category) && d.distanceKm <= maxDistance);
  }
}

const engine = new TestDealEngine();
const mockDeals = [
  { id: '1', category: 'Dining', distanceKm: 1.2 },
  { id: '2', category: 'Fitness', distanceKm: 4.5 }
];

console.log('Test 1: Category & Radius Filter...');
const filtered = engine.filterDeals(mockDeals, 'Dining', 2.0);
assert.strictEqual(filtered.length, 1);
assert.strictEqual(filtered[0].id, '1');
console.log('✅ Passed!');

console.log('------------------------------------------');
console.log('Unit Tests Completed Successfully! 🚀');
