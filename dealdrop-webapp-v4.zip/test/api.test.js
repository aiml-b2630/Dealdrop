// Integration Test Suite for Express REST API and Input Validation
const assert = require('assert');
const { validateDealPayload } = require('../validator');
const { generateToken } = require('../auth');

console.log('==========================================');
console.log(' Running DealDrop Integration Tests (v4)  ');
console.log('==========================================');

// Test 1: Schema Validation (Rejects Invalid Category)
console.log('Test 1: Reject Invalid Category Payload...');
const invalidCategoryResult = validateDealPayload({
  title: 'Test Deal',
  category: 'IllegalCategory',
  discount: 20,
  quota: 10,
  distanceKm: 2,
  merchant: 'Cafe'
});
assert.strictEqual(invalidCategoryResult.valid, false);
console.log('✅ Passed (Rejected invalid category)!');

// Test 2: Schema Validation (Rejects Out-of-bounds Discount)
console.log('Test 2: Reject Out-of-bounds Discount...');
const invalidDiscountResult = validateDealPayload({
  title: 'Test Deal',
  category: 'Dining',
  discount: 150, // > 100%
  quota: 10,
  distanceKm: 2,
  merchant: 'Cafe'
});
assert.strictEqual(invalidDiscountResult.valid, false);
console.log('✅ Passed (Rejected >100% discount)!');

// Test 3: JWT Token Generation & Verification
console.log('Test 3: JWT Merchant Authentication Flow...');
const token = generateToken('merchant_001');
assert.strictEqual(typeof token, 'string');
assert.ok(token.length > 20);
console.log('✅ Passed (Generated valid JWT bearer token)!');

console.log('------------------------------------------');
console.log('All API Integration Tests Passed! 🚀');
