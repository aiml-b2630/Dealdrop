// SQLite Database Driver with Transaction Support
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, 'dealdrop.db');

const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  // Deals table
  db.run(`
    CREATE TABLE IF NOT EXISTS deals (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      discount INTEGER NOT NULL,
      code TEXT NOT NULL,
      quota INTEGER NOT NULL,
      claimedCount INTEGER DEFAULT 0,
      distanceKm REAL NOT NULL,
      expiresInMinutes INTEGER NOT NULL,
      expiryTimestamp INTEGER NOT NULL,
      merchant TEXT NOT NULL,
      district TEXT NOT NULL,
      views INTEGER DEFAULT 0,
      createdAt INTEGER NOT NULL
    )
  `);

  // Claims table for anti-hoarding tracking
  db.run(`
    CREATE TABLE IF NOT EXISTS claims (
      id TEXT PRIMARY KEY,
      dealId TEXT NOT NULL,
      voucherCode TEXT NOT NULL,
      claimedAt INTEGER NOT NULL,
      expiresAt INTEGER NOT NULL,
      status TEXT DEFAULT 'ACTIVE',
      FOREIGN KEY(dealId) REFERENCES deals(id)
    )
  `);

  // Pre-aggregated analytics summary table
  db.run(`
    CREATE TABLE IF NOT EXISTS analytics_summary (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      totalViews INTEGER DEFAULT 0,
      totalClaims INTEGER DEFAULT 0,
      estimatedWalkIns INTEGER DEFAULT 0,
      totalSavings REAL DEFAULT 0.0
    )
  `);

  db.run(`
    INSERT OR IGNORE INTO analytics_summary (id, totalViews, totalClaims, estimatedWalkIns, totalSavings)
    VALUES (1, 142, 38, 32, 485.00)
  `);
});

// Helper functions wrapping DB operations in Promises & Transactions
function runQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

function getQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function allQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

// Transactional Voucher Claim (Atomic quota decrement)
async function claimVoucherTransaction(dealId) {
  await runQuery('BEGIN IMMEDIATE TRANSACTION');
  try {
    const deal = await getQuery('SELECT * FROM deals WHERE id = ?', [dealId]);
    if (!deal) {
      await runQuery('ROLLBACK');
      return { success: false, status: 404, message: 'Deal not found' };
    }

    if (deal.claimedCount >= deal.quota) {
      await runQuery('ROLLBACK');
      return { success: false, status: 400, message: 'Deal quota exhausted' };
    }

    const now = Date.now();
    if (now > deal.expiryTimestamp) {
      await runQuery('ROLLBACK');
      return { success: false, status: 400, message: 'Deal has expired' };
    }

    // Decrement remaining quota atomically
    await runQuery('UPDATE deals SET claimedCount = claimedCount + 1 WHERE id = ?', [dealId]);

    // Record voucher claim token
    const claimId = 'CLM-' + Math.random().toString(36).substr(2, 7).toUpperCase();
    const expiresAt = now + (2 * 60 * 60 * 1000); // 2 hour anti-hoarding window
    await runQuery(
      'INSERT INTO claims (id, dealId, voucherCode, claimedAt, expiresAt) VALUES (?, ?, ?, ?, ?)',
      [claimId, dealId, deal.code, now, expiresAt]
    );

    // Update pre-aggregated analytics atomically (O(1))
    const savings = (deal.discount / 100) * 15.0; // Estimated savings base
    await runQuery(`
      UPDATE analytics_summary 
      SET totalClaims = totalClaims + 1,
          estimatedWalkIns = CAST((totalClaims + 1) * 0.85 AS INT),
          totalSavings = totalSavings + ?
      WHERE id = 1
    `, [savings]);

    await runQuery('COMMIT');
    return {
      success: true,
      voucherCode: deal.code,
      remainingQuota: deal.quota - (deal.claimedCount + 1),
      claimId,
      expiresAt
    };
  } catch (err) {
    await runQuery('ROLLBACK');
    throw err;
  }
}

module.exports = {
  db,
  runQuery,
  getQuery,
  allQuery,
  claimVoucherTransaction
};
