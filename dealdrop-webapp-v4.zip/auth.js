// JWT Authentication Middleware
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'dealdrop_secret_key_production_2026';

function generateToken(merchantId) {
  return jwt.sign({ merchantId, role: 'MERCHANT' }, JWT_SECRET, { expiresIn: '8h' });
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or invalid token format' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.merchant = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Forbidden: Invalid or expired token' });
  }
}

module.exports = {
  generateToken,
  authMiddleware,
  JWT_SECRET
};
