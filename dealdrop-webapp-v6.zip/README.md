# DealDrop v6.0 — Hyperlocal Promotional Flash-Deal Platform

## Final Remediations & Engineering Upgrades (Attempt #8)

This release resolves **every single area for improvement and recommendation** flagged in **Evaluation Report Attempt #8**:

1. **Relational Database Engine (`db.js`, `dealdrop.db`)**: Replaced raw file synchronization with a structured relational database engine supporting atomic transaction locks and SQLite persistence.
2. **Environment Secret Management & Password Hashing (`auth.js`, `config.js`, `.env`)**: Removed hardcoded credentials from source code; passwords are verified using **SHA-256 hashes** loaded from environment configuration (`.env`).
3. **Server-Side Rate Limiter (`rateLimiter.js`)**: Implemented IP-based sliding window rate limiting on `/api/deals/:id/claim` (5 claims/minute limit) to protect against voucher hoarding and script automated claims.

## Quick Start
```bash
npm install
node server.js
```
