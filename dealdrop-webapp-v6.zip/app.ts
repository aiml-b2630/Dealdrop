// DealDrop Core Business Engine & Decoupled Architecture
export interface Deal {
  id: number;
  title: string;
  merchant: string;
  category: 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';
  distanceKm: number;
  originalPrice: number;
  discountedPrice: number;
  discountPct: number;
  quota: number;
  remainingQuota: number;
  expiryHours: number;
  expiryTime: number;
  isHappyHour: boolean;
  code: string;
}

export class DealService {
  static filterDeals(deals: Deal[], category: string, maxRadius: number, happyHourOnly: boolean = false): Deal[] {
    return deals.filter(deal => {
      const matchCat = (category === 'All' || deal.category === category);
      const matchRadius = deal.distanceKm <= maxRadius;
      const matchHH = !happyHourOnly || deal.isHappyHour;
      return matchCat && matchRadius && matchHH;
    });
  }

  static formatTimeRemaining(expiryTime: number): string {
    const diff = expiryTime - Date.now();
    if (diff <= 0) return 'Expired';
    const hours = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    return `${hours}h ${mins}m ${secs}s`;
  }
}
