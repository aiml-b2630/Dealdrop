# DealDrop REST API v6.0 Documentation
- `GET /api/deals`: List active deals
- `POST /api/deals/:id/claim`: Claim voucher token (Rate limited to 5 claims/minute per IP)
- `POST /api/auth/login`: Merchant login (Validates SHA-256 hashed passwords against env secrets)
