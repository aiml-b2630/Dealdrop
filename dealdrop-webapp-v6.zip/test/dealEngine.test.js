const assert = require('assert');
const { DealService } = require('../app');

console.log('==========================================');
console.log(' Running Deal Engine Unit Tests (v6.0)   ');
console.log('==========================================');

const mockDeals = [
  { id: 1, title: 'Coffee', category: 'Dining', distanceKm: 1.0, isHappyHour: true },
  { id: 2, title: 'Gym', category: 'Fitness', distanceKm: 4.0, isHappyHour: false }
];

// Test 1: Category Filtering
const dining = DealService.filterDeals(mockDeals, 'Dining', 5.0);
assert.strictEqual(dining.length, 1);
assert.strictEqual(dining[0].title, 'Coffee');
console.log('Test 1: Category Filtering... ✅ Passed!');

// Test 2: Radius Filtering
const radiusMatch = DealService.filterDeals(mockDeals, 'All', 2.0);
assert.strictEqual(radiusMatch.length, 1);
assert.strictEqual(radiusMatch[0].title, 'Coffee');
console.log('Test 2: Distance Radius Filtering... ✅ Passed!');

console.log('------------------------------------------');
console.log('All Unit Test Cases Executed Successfully! 🚀\n');
