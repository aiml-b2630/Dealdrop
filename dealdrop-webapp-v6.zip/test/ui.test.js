const assert = require('assert');
const { DealService } = require('../app');

console.log('==========================================');
console.log(' Running UI & Component Helper Tests     ');
console.log('==========================================');

const formatted = DealService.formatTimeRemaining(Date.now() + 3600000);
assert(formatted.includes('1h 0m 0s') || formatted.includes('0h 59m'));
console.log('UI Test 1: Countdown Clock Formatting... ✅ Passed!');

console.log('------------------------------------------');
console.log('All UI Tests Executed Successfully! 🚀\n');
