const assert = require('assert');
const http = require('http');
const server = require('../server');
const config = require('../config');

const PORT = 3099;
process.env.PORT = PORT;

function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port: PORT,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    }, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: data ? JSON.parse(data) : {} });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runApiTests() {
  console.log('==========================================');
  console.log(' Running REST API & Rate Limit Tests (v6)');
  console.log('==========================================');

  await new Promise(resolve => server.listen(PORT, resolve));

  try {
    // API Test 1: GET /api/deals
    const resDeals = await request('GET', '/api/deals');
    assert.strictEqual(resDeals.status, 200);
    assert(Array.isArray(resDeals.body));
    console.log('API Test 1: GET /api/deals... ✅ Passed!');

    // API Test 2: Hashed Password Login
    const resLogin = await request('POST', '/api/auth/login', { username: 'admin', password: 'password123' });
    assert.strictEqual(resLogin.status, 200);
    assert(resLogin.body.token);
    console.log('API Test 2: Hashed Auth Login... ✅ Passed!');

    // API Test 3: Claim Voucher & Rate Limiter
    let claimed = 0;
    for (let i = 0; i < 6; i++) {
      const resClaim = await request('POST', '/api/deals/1/claim');
      if (resClaim.status === 200) claimed++;
      else if (resClaim.status === 429) {
        assert.strictEqual(resClaim.status, 429);
        console.log('API Test 3: Rate Limiter (429 Too Many Requests)... ✅ Passed!');
        break;
      }
    }

    console.log('------------------------------------------');
    console.log('All REST API Tests Passed! 🚀\n');
  } finally {
    server.close();
  }
}

if (require.main === module) {
  runApiTests().catch(err => {
    console.error('API Test Error:', err);
    process.exit(1);
  });
}
