// DealDrop v6.0 Production Client Engine
class DealAppController {
  constructor() {
    this.deals = [];
    this.currentCategory = 'All';
    this.maxRadius = 5.0;
    this.happyHourFilter = false;
    this.authToken = localStorage.getItem('dealdrop_auth_token') || null;
    this.init();
  }

  async init() {
    await this.fetchDeals();
    await this.fetchAnalytics();
    this.setupEventListeners();
    this.startCountdownTimer();
  }

  async fetchDeals() {
    try {
      const res = await fetch('/api/deals');
      this.deals = await res.json();
      this.render();
    } catch (e) {
      console.error('Error loading deals:', e);
    }
  }

  async fetchAnalytics() {
    try {
      const res = await fetch('/api/analytics');
      const data = await res.json();
      document.getElementById('statViews').textContent = data.views || 0;
      document.getElementById('statClaims').textContent = data.claims || 0;
      document.getElementById('statWalkIns').textContent = data.walkIns || 0;
      document.getElementById('statSavings').textContent = '$' + (data.totalSavings || 0);
    } catch (e) {
      console.error('Error fetching analytics:', e);
    }
  }

  setupEventListeners() {
    // Radius slider
    const radiusSlider = document.getElementById('radiusSlider');
    if (radiusSlider) {
      radiusSlider.addEventListener('input', (e) => {
        this.maxRadius = parseFloat(e.target.value);
        document.getElementById('radiusVal').textContent = `${this.maxRadius} km`;
        this.render();
      });
    }

    // Category Tabs
    document.querySelectorAll('.cat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.currentCategory = e.target.dataset.cat;
        this.render();
      });
    }

    // Login modal
    const loginBtn = document.getElementById('loginModalBtn');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => this.handleLogin());
    }
  }

  async claimDeal(id) {
    try {
      const res = await fetch(`/api/deals/${id}/claim`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Failed to claim voucher');
        return;
      }
      alert(`🎉 Voucher Claimed! Token: ${data.voucherToken}\nCode: ${data.deal.code}`);
      await this.fetchDeals();
      await this.fetchAnalytics();
    } catch (e) {
      alert('Error claiming voucher. Please try again.');
    }
  }

  shareWhatsApp(title, code) {
    const text = encodeURIComponent(`🔥 Check out this deal on DealDrop! "${title}" - Use Voucher Code: ${code}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  }

  render() {
    const container = document.getElementById('dealsGrid');
    if (!container) return;

    const filtered = this.deals.filter(d => {
      const catMatch = this.currentCategory === 'All' || d.category === this.currentCategory;
      const radMatch = d.distanceKm <= this.maxRadius;
      return catMatch && radMatch;
    });

    if (filtered.length === 0) {
      container.innerHTML = '<div class="no-deals">No deals found in this radius or category.</div>';
      return;
    }

    container.innerHTML = filtered.map(deal => `
      <div class="deal-card ${deal.isHappyHour ? 'happy-hour-card' : ''}">
        ${deal.isHappyHour ? '<span class="badge-hh">⚡ Happy Hour 40% OFF</span>' : ''}
        <div class="deal-header">
          <h3>${deal.title}</h3>
          <span class="merchant-name">📍 ${deal.merchant} (${deal.distanceKm} km)</span>
        </div>
        <div class="deal-price">
          <span class="disc-price">$${deal.discountedPrice}</span>
          <span class="orig-price">$${deal.originalPrice}</span>
          <span class="disc-badge">${deal.discountPct}% OFF</span>
        </div>
        <div class="deal-quota">
          <div class="quota-bar"><div class="quota-fill" style="width: ${(deal.remainingQuota / deal.quota) * 100}%"></div></div>
          <small>${deal.remainingQuota} of ${deal.quota} left</small>
        </div>
        <div class="deal-timer" id="timer-${deal.id}">Ends in: calculating...</div>
        <div class="deal-actions">
          <button class="btn-primary" onclick="app.claimDeal(${deal.id})" ${deal.remainingQuota <= 0 ? 'disabled' : ''}>
            ${deal.remainingQuota > 0 ? 'Claim Deal' : 'Sold Out'}
          </button>
          <button class="btn-share" onclick="app.shareWhatsApp('${deal.title}', '${deal.code}')">📲 Share</button>
        </div>
      </div>
    `).join('');
  }

  startCountdownTimer() {
    setInterval(() => {
      this.deals.forEach(deal => {
        const el = document.getElementById(`timer-${deal.id}`);
        if (el) {
          const diff = deal.expiryTime - Date.now();
          if (diff <= 0) {
            el.textContent = 'Expired';
          } else {
            const h = Math.floor(diff / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);
            el.textContent = `Ends in: ${h}h ${m}m ${s}s`;
          }
        }
      });
    }, 1000);
  }
}

if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    window.app = new DealAppController();
  });
}
