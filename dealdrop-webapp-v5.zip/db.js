const fs = require('fs');
const path = require('path');
const config = require('./config');
const logger = require('./logger');

const dbFile = path.join(__dirname, 'dealdrop.json');

let dbData = {
  deals: [],
  claims: [],
  analytics: {
    totalViews: 1420,
    totalClaims: 318,
    totalRedemptions: 270,
    totalSavings: 4850.0
  }
};

function seedDb() {
  const now = Date.now();
  dbData.deals = [
    { id: 'd1', title: '40% Off Artisan Coffee & Pastry', merchant: 'Artisan Cafe', category: 'Dining', district: 'Downtown Core', discountPercent: 40, originalPrice: 15.00, dealPrice: 9.00, distanceKm: 0.8, expiryTimestamp: now + 7200000, totalQuota: 25, claimedCount: 12, code: 'PASTRY40', isHappyHour: 1, createdAt: now },
    { id: 'd2', title: '1+1 Free Gym Day Pass', merchant: 'FitPulse Hub', category: 'Fitness', district: 'Westend Heights', discountPercent: 50, originalPrice: 30.00, dealPrice: 15.00, distanceKm: 1.2, expiryTimestamp: now + 10800000, totalQuota: 15, claimedCount: 7, code: 'FITFREE', isHappyHour: 0, createdAt: now },
    { id: 'd3', title: '25% Off Haircut & Styling', merchant: 'Glow Salon', category: 'Services', district: 'Downtown Core', discountPercent: 25, originalPrice: 60.00, dealPrice: 45.00, distanceKm: 0.5, expiryTimestamp: now + 14400000, totalQuota: 10, claimedCount: 4, code: 'STYLE25', isHappyHour: 0, createdAt: now },
    { id: 'd4', title: 'Flat $10 Off Eco Dry Cleaning', merchant: 'Green Cleaners', category: 'Services', district: 'Eastside District', discountPercent: 30, originalPrice: 35.00, dealPrice: 25.00, distanceKm: 2.5, expiryTimestamp: now + 18000000, totalQuota: 20, claimedCount: 11, code: 'CLEAN10', isHappyHour: 0, createdAt: now },
    { id: 'd5', title: '30% Off Gourmet Pizza Slice Combo', merchant: 'Bella Italia', category: 'Dining', district: 'Northside Plaza', discountPercent: 30, originalPrice: 20.00, dealPrice: 14.00, distanceKm: 1.8, expiryTimestamp: now + 5400000, totalQuota: 30, claimedCount: 18, code: 'PIZZA30', isHappyHour: 1, createdAt: now },
    { id: 'd6', title: '50% Off Full Body Swedish Massage', merchant: 'Serenity Spa', category: 'Wellness', district: 'Downtown Core', discountPercent: 50, originalPrice: 100.00, dealPrice: 50.00, distanceKm: 0.9, expiryTimestamp: now + 9000000, totalQuota: 8, claimedCount: 5, code: 'RELAX50', isHappyHour: 0, createdAt: now },
    { id: 'd7', title: '2-for-1 Indie Cinema Ticket', merchant: 'Starlight Cinema', category: 'Entertainment', district: 'Westend Heights', discountPercent: 50, originalPrice: 24.00, dealPrice: 12.00, distanceKm: 2.1, expiryTimestamp: now + 12600000, totalQuota: 40, claimedCount: 22, code: 'MOVIE2FOR1', isHappyHour: 0, createdAt: now },
    { id: 'd8', title: '35% Off Boutique Designer Apparel', merchant: 'Velvet Thread', category: 'Services', district: 'Northside Plaza', discountPercent: 35, originalPrice: 120.00, dealPrice: 78.00, distanceKm: 3.2, expiryTimestamp: now + 16200000, totalQuota: 12, claimedCount: 6, code: 'BOUTIQUE35', isHappyHour: 0, createdAt: now },
    { id: 'd9', title: 'Flat $5 Off Fresh Berry Smoothies', merchant: 'Juice Lab', category: 'Dining', district: 'Downtown Core', discountPercent: 40, originalPrice: 12.00, dealPrice: 7.00, distanceKm: 0.4, expiryTimestamp: now + 3600000, totalQuota: 50, claimedCount: 39, code: 'SMOOTHIE5', isHappyHour: 1, createdAt: now },
    { id: 'd10', title: '45% Off Hot Yoga Trial Session', merchant: 'Zen Studio', category: 'Fitness', district: 'Eastside District', discountPercent: 45, originalPrice: 40.00, dealPrice: 22.00, distanceKm: 2.8, expiryTimestamp: now + 8000000, totalQuota: 15, claimedCount: 8, code: 'YOGA45', isHappyHour: 0, createdAt: now },
    { id: 'd11', title: '30% Off Organic Facial Treatment', merchant: 'Pure Skin Spa', category: 'Wellness', district: 'Westend Heights', discountPercent: 30, originalPrice: 85.00, dealPrice: 59.50, distanceKm: 1.5, expiryTimestamp: now + 11000000, totalQuota: 10, claimedCount: 3, code: 'FACIAL30', isHappyHour: 0, createdAt: now },
    { id: 'd12', title: 'Buy 1 Get 1 Arcade Tokens', merchant: 'Retro Arcade Bar', category: 'Entertainment', district: 'Downtown Core', discountPercent: 50, originalPrice: 20.00, dealPrice: 10.00, distanceKm: 0.7, expiryTimestamp: now + 15000000, totalQuota: 30, claimedCount: 14, code: 'ARCADEBOGO', isHappyHour: 1, createdAt: now },
    { id: 'd13', title: '20% Off Specialty Roaster Beans', merchant: 'Bean Craft', category: 'Dining', district: 'Eastside District', discountPercent: 20, originalPrice: 25.00, dealPrice: 20.00, distanceKm: 4.1, expiryTimestamp: now + 19000000, totalQuota: 25, claimedCount: 9, code: 'BEANS20', isHappyHour: 0, createdAt: now },
    { id: 'd14', title: '40% Off Pilates Reformer Class', merchant: 'Core Reform', category: 'Fitness', district: 'Northside Plaza', discountPercent: 40, originalPrice: 45.00, dealPrice: 27.00, distanceKm: 3.5, expiryTimestamp: now + 6500000, totalQuota: 12, claimedCount: 5, code: 'CORE40', isHappyHour: 0, createdAt: now },
    { id: 'd15', title: 'Flat $15 Off Bicycle Tune-Up', merchant: 'Metro Bikes', category: 'Services', district: 'Westend Heights', discountPercent: 25, originalPrice: 60.00, dealPrice: 45.00, distanceKm: 2.3, expiryTimestamp: now + 13000000, totalQuota: 15, claimedCount: 8, code: 'BIKE15', isHappyHour: 0, createdAt: now },
    { id: 'd16', title: '35% Off Escape Room Adventure', merchant: 'Mystery Vault', category: 'Entertainment', district: 'Eastside District', discountPercent: 35, originalPrice: 90.00, dealPrice: 58.50, distanceKm: 4.8, expiryTimestamp: now + 17500000, totalQuota: 20, claimedCount: 11, code: 'ESCAPE35', isHappyHour: 0, createdAt: now }
  ];
  saveDb();
}

function saveDb() {
  try {
    fs.writeFileSync(dbFile, JSON.stringify(dbData, null, 2), 'utf8');
  } catch (err) {
    logger.error('Failed to write database file:', err);
  }
}

function initDb() {
  return new Promise((resolve) => {
    if (fs.existsSync(dbFile)) {
      try {
        const raw = fs.readFileSync(dbFile, 'utf8');
        dbData = JSON.parse(raw);
      } catch (e) {
        seedDb();
      }
    } else {
      seedDb();
    }
    resolve();
  });
}

function getDeals(category, radius, happyHour) {
  const now = Date.now();
  let list = dbData.deals.filter(d => d.expiryTimestamp > now);

  if (category && category !== 'All') {
    list = list.filter(d => d.category === category);
  }
  if (radius) {
    const radNum = parseFloat(radius);
    list = list.filter(d => d.distanceKm <= radNum);
  }
  if (happyHour === 'true') {
    list = list.filter(d => d.isHappyHour === 1 || d.discountPercent >= 40);
  }

  // Atomic view count increment O(1)
  dbData.analytics.totalViews += 1;
  saveDb();
  return list;
}

function claimVoucherAtomic(dealId) {
  return new Promise((resolve, reject) => {
    // Atomic transaction simulation
    const deal = dbData.deals.find(d => d.id === dealId);
    if (!deal) return reject(new Error('Deal not found'));

    if (deal.claimedCount >= deal.totalQuota) {
      return reject(new Error('Voucher quota exhausted'));
    }

    const now = Date.now();
    if (deal.expiryTimestamp <= now) {
      return reject(new Error('Deal has expired'));
    }

    deal.claimedCount += 1;
    const claimId = 'clm_' + Math.random().toString(36).substr(2, 9);
    const expiresAt = now + 7200000;
    const savings = deal.originalPrice - deal.dealPrice;

    dbData.claims.push({
      claimId,
      dealId,
      code: deal.code,
      claimedAt: now,
      expiresAt
    });

    dbData.analytics.totalClaims += 1;
    dbData.analytics.totalSavings += savings;
    saveDb();

    resolve({
      claimId,
      dealId,
      code: deal.code,
      remainingQuota: deal.totalQuota - deal.claimedCount,
      expiresAt,
      dealTitle: deal.title,
      merchant: deal.merchant
    });
  });
}

function addDeal(dealData) {
  const now = Date.now();
  const id = 'd_' + Math.random().toString(36).substr(2, 9);
  const expiryTimestamp = now + (dealData.expiryHours * 3600000);
  const isHappyHour = dealData.discountPercent >= 40 ? 1 : 0;

  const deal = {
    id,
    title: dealData.title,
    merchant: dealData.merchant,
    category: dealData.category,
    district: dealData.district,
    discountPercent: dealData.discountPercent,
    originalPrice: dealData.originalPrice,
    dealPrice: dealData.dealPrice,
    distanceKm: dealData.distanceKm,
    expiryTimestamp,
    totalQuota: dealData.totalQuota,
    claimedCount: 0,
    code: dealData.code,
    isHappyHour,
    createdAt: now
  };

  dbData.deals.unshift(deal);
  saveDb();
  return deal;
}

function getAnalytics() {
  const summary = dbData.analytics;
  const conversionRate = summary.totalViews > 0
    ? ((summary.totalClaims / summary.totalViews) * 100).toFixed(1)
    : '0.0';
  const estimatedWalkIns = Math.round(summary.totalClaims * 0.85);

  return {
    totalViews: summary.totalViews,
    totalClaims: summary.totalClaims,
    conversionRate: `${conversionRate}%`,
    estimatedWalkIns,
    totalSavings: summary.totalSavings.toFixed(2)
  };
}

module.exports = {
  initDb,
  getDeals,
  claimVoucherAtomic,
  addDeal,
  getAnalytics
};
