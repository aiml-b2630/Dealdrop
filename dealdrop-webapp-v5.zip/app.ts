// DealDrop Decoupled TypeScript Client Engine (v5.0)

export interface Deal {
  id: string;
  title: string;
  merchant: string;
  category: string;
  district: string;
  discountPercent: number;
  originalPrice: number;
  dealPrice: number;
  distanceKm: number;
  expiryTimestamp: number;
  totalQuota: number;
  claimedCount: number;
  code: string;
  isHappyHour: number;
  lat?: number;
  lng?: number;
}

export interface ClaimResult {
  claimId: string;
  dealId: string;
  code: string;
  remainingQuota: number;
  expiresAt: number;
  dealTitle: string;
  merchant: string;
}

// Pure Headless Business Logic Service
export class DealService {
  static filterDeals(
    deals: Deal[],
    category: string = 'All',
    maxRadiusKm: number = 5.0,
    district: string = 'All',
    happyHourOnly: boolean = false,
    searchQuery: string = ''
  ): Deal[] {
    const query = searchQuery.trim().toLowerCase();
    return deals.filter((deal) => {
      const matchCategory = category === 'All' || deal.category === category;
      const matchRadius = deal.distanceKm <= maxRadiusKm;
      const matchDistrict = district === 'All' || deal.district === district;
      const matchHappyHour = !happyHourOnly || deal.isHappyHour === 1 || deal.discountPercent >= 40;
      const matchSearch =
        !query ||
        deal.title.toLowerCase().includes(query) ||
        deal.merchant.toLowerCase().includes(query) ||
        deal.code.toLowerCase().includes(query);

      return matchCategory && matchRadius && matchDistrict && matchHappyHour && matchSearch;
    });
  }

  static formatCountdown(expiryTimestamp: number): { text: string; isUrgent: boolean } {
    const remainingMs = expiryTimestamp - Date.now();
    if (remainingMs <= 0) {
      return { text: 'EXPIRED', isUrgent: true };
    }

    const totalSeconds = Math.floor(remainingMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const isUrgent = remainingMs <= 3600000; // Under 60 mins
    const text = `Ends in ${hours}h ${minutes}m ${seconds}s`;
    return { text, isUrgent };
  }
}
