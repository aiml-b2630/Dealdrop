// DealDrop Client Runtime Engine (v5.0)

class DealService {
  static filterDeals(deals, category = 'All', maxRadiusKm = 5.0, district = 'All', happyHourOnly = false, searchQuery = '') {
    const query = searchQuery.trim().toLowerCase();
    return deals.filter((deal) => {
      const matchCategory = category === 'All' || deal.category === category;
      const matchRadius = deal.distanceKm <= maxRadiusKm;
      const matchDistrict = district === 'All' || deal.district === district;
      const matchHappyHour = !happyHourOnly || deal.isHappyHour === 1 || deal.discountPercent >= 40;
      const matchSearch = !query ||
        deal.title.toLowerCase().includes(query) ||
        deal.merchant.toLowerCase().includes(query) ||
        deal.code.toLowerCase().includes(query);

      return matchCategory && matchRadius && matchDistrict && matchHappyHour && matchSearch;
    });
  }

  static formatCountdown(expiryTimestamp) {
    const remainingMs = expiryTimestamp - Date.now();
    if (remainingMs <= 0) return { text: 'EXPIRED', isUrgent: true };
    const totalSeconds = Math.floor(remainingMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return {
      text: `Ends in ${hours}h ${minutes}m ${seconds}s`,
      isUrgent: remainingMs <= 3600000
    };
  }
}

// Export for Node unit testing if available
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DealService };
}

// App Controller (DOM Client context)
let allDeals = [];
let currentCategory = 'All';
let currentRadius = 5.0;
let currentDistrict = 'All';
let currentHappyHourOnly = false;
let currentSearch = '';
let leafletMap = null;
let leafletMarkers = [];

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    initApp();
  });
}

async function initApp() {
  setupEventListeners();
  await fetchDeals();
  await fetchAnalytics();
  startTimerLoop();
  checkAuthToken();
}

function setupEventListeners() {
  if (typeof document === 'undefined') return;

  // Category tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentCategory = btn.getAttribute('data-category');
      renderDeals();
    });
  });

  // Radius slider
  const slider = document.getElementById('radius-slider');
  if (slider) {
    slider.addEventListener('input', (e) => {
      currentRadius = parseFloat(e.target.value);
      document.getElementById('radius-value').innerText = `${currentRadius.toFixed(1)} km`;
      renderDeals();
    });
  }

  // District select
  const districtSelect = document.getElementById('district-select');
  if (districtSelect) {
    districtSelect.addEventListener('change', (e) => {
      currentDistrict = e.target.value;
      renderDeals();
    });
  }

  // Search input
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearch = e.target.value;
      renderDeals();
    });
  }

  // Happy Hour filter button
  const hhBtn = document.getElementById('btn-happy-hour-filter');
  if (hhBtn) {
    hhBtn.addEventListener('click', () => {
      currentHappyHourOnly = !currentHappyHourOnly;
      hhBtn.classList.toggle('active', currentHappyHourOnly);
      renderDeals();
    });
  }

  // Feed vs Map Toggle
  const btnFeed = document.getElementById('btn-view-feed');
  const btnMap = document.getElementById('btn-view-map');
  const feedSec = document.getElementById('feed-container');
  const mapSec = document.getElementById('map-section');

  if (btnFeed && btnMap) {
    btnFeed.addEventListener('click', () => {
      btnFeed.classList.add('active');
      btnMap.classList.remove('active');
      feedSec.style.display = 'grid';
      mapSec.style.display = 'none';
    });
    btnMap.addEventListener('click', () => {
      btnMap.classList.add('active');
      btnFeed.classList.remove('active');
      feedSec.style.display = 'none';
      mapSec.style.display = 'block';
      initMap();
    });
  }

  // Auth & Cockpit Modals
  const btnLoginModal = document.getElementById('btn-login-modal');
  const loginModal = document.getElementById('login-modal');
  const btnCloseLogin = document.getElementById('btn-close-login-modal');
  const loginForm = document.getElementById('login-form');
  const btnMerchantPanel = document.getElementById('btn-merchant-panel');
  const cockpitSec = document.getElementById('merchant-cockpit-section');
  const btnCloseCockpit = document.getElementById('btn-close-cockpit');

  if (btnLoginModal) btnLoginModal.addEventListener('click', () => loginModal.style.display = 'flex');
  if (btnCloseLogin) btnCloseLogin.addEventListener('click', () => loginModal.style.display = 'none');
  if (btnMerchantPanel) btnMerchantPanel.addEventListener('click', () => cockpitSec.style.display = 'block');
  if (btnCloseCockpit) btnCloseCockpit.addEventListener('click', () => cockpitSec.style.display = 'none');

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('login-username').value;
      const password = document.getElementById('login-password').value;

      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (res.ok) {
          localStorage.setItem('dealdrop_token', data.token);
          loginModal.style.display = 'none';
          checkAuthToken();
          cockpitSec.style.display = 'block';
        } else {
          alert('Login failed: ' + (data.error || 'Invalid credentials'));
        }
      } catch (err) {
        alert('Network error during login');
      }
    });
  }

  // Create Deal Form
  const createForm = document.getElementById('create-deal-form');
  if (createForm) {
    createForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = localStorage.getItem('dealdrop_token');
      if (!token) return alert('Merchant session expired. Please log in.');

      const payload = {
        title: document.getElementById('form-title').value,
        merchant: document.getElementById('form-merchant').value,
        category: document.getElementById('form-category').value,
        district: document.getElementById('form-district').value,
        discountPercent: parseFloat(document.getElementById('form-discount').value),
        originalPrice: parseFloat(document.getElementById('form-orig-price').value),
        dealPrice: parseFloat(document.getElementById('form-deal-price').value),
        distanceKm: parseFloat(document.getElementById('form-distance').value),
        totalQuota: parseInt(document.getElementById('form-quota').value, 10),
        expiryHours: parseInt(document.getElementById('form-expiry').value, 10),
        code: document.getElementById('form-code').value
      };

      try {
        const res = await fetch('/api/deals', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (res.ok) {
          alert('Flash Deal Broadcasted Successfully!');
          createForm.reset();
          await fetchDeals();
          await fetchAnalytics();
        } else {
          alert('Failed to publish deal: ' + (data.details ? data.details.join('\\n') : data.error));
        }
      } catch (err) {
        alert('Network error publishing deal.');
      }
    });
  }

  // Voucher modal close
  const btnCloseVoucher = document.getElementById('btn-close-voucher-modal');
  const voucherModal = document.getElementById('voucher-modal');
  if (btnCloseVoucher) btnCloseVoucher.addEventListener('click', () => voucherModal.style.display = 'none');

  // Copy code button
  const btnCopy = document.getElementById('btn-copy-code');
  if (btnCopy) {
    btnCopy.addEventListener('click', () => {
      const code = document.getElementById('modal-voucher-code').innerText;
      navigator.clipboard.writeText(code).then(() => {
        btnCopy.innerText = '✅ Copied!';
        setTimeout(() => btnCopy.innerText = '📋 Copy Code', 2000);
      });
    });
  }
}

function checkAuthToken() {
  if (typeof localStorage === 'undefined' || typeof document === 'undefined') return;
  const token = localStorage.getItem('dealdrop_token');
  const btnLoginModal = document.getElementById('btn-login-modal');
  const btnMerchantPanel = document.getElementById('btn-merchant-panel');
  if (token) {
    if (btnLoginModal) btnLoginModal.style.display = 'none';
    if (btnMerchantPanel) btnMerchantPanel.style.display = 'inline-flex';
  }
}

async function fetchDeals() {
  try {
    const res = await fetch('/api/deals');
    if (res.ok) {
      allDeals = await res.json();
      renderDeals();
    }
  } catch (err) {
    console.error('Error fetching deals:', err);
  }
}

async function fetchAnalytics() {
  try {
    const res = await fetch('/api/analytics');
    if (res.ok) {
      const data = await res.json();
      if (typeof document !== 'undefined') {
        const v = document.getElementById('metric-views');
        const c = document.getElementById('metric-claims');
        const cr = document.getElementById('metric-conversion');
        const w = document.getElementById('metric-walkins');
        const s = document.getElementById('metric-savings');
        if (v) v.innerText = data.totalViews.toLocaleString();
        if (c) c.innerText = data.totalClaims.toLocaleString();
        if (cr) cr.innerText = data.conversionRate;
        if (w) w.innerText = data.estimatedWalkIns.toLocaleString();
        if (s) s.innerText = `$${data.totalSavings}`;
      }
    }
  } catch (err) {
    console.error('Error fetching analytics:', err);
  }
}

function renderDeals() {
  if (typeof document === 'undefined') return;
  const feed = document.getElementById('feed-container');
  if (!feed) return;

  const filtered = DealService.filterDeals(
    allDeals,
    currentCategory,
    currentRadius,
    currentDistrict,
    currentHappyHourOnly,
    currentSearch
  );

  feed.innerHTML = '';
  if (filtered.length === 0) {
    feed.innerHTML = `<div class="empty-msg" style="grid-column: 1/-1; text-align: center; padding: 40px; color: #64748b;">
      <h3>No matching flash deals found</h3>
      <p>Try expanding your proximity radius or changing your selected category tab.</p>
    </div>`;
    return;
  }

  filtered.forEach((deal) => {
    const card = document.createElement('div');
    const isHH = deal.isHappyHour === 1 || deal.discountPercent >= 40;
    card.className = `deal-card ${isHH ? 'happy-hour-card' : ''}`;

    const countdown = DealService.formatCountdown(deal.expiryTimestamp);
    const quotaPct = Math.min(100, Math.round((deal.claimedCount / deal.totalQuota) * 100));

    card.innerHTML = `
      <div class="card-top">
        <span class="category-badge">${deal.category}</span>
        <span class="discount-badge ${isHH ? 'hh-badge' : ''}">${deal.discountPercent}% OFF ${isHH ? '⚡' : ''}</span>
      </div>

      <h3 class="deal-title">${deal.title}</h3>
      <p class="merchant-info">🏪 ${deal.merchant} • 📍 ${deal.district}</p>

      <div class="pricing-row">
        <span class="deal-price">$${deal.dealPrice.toFixed(2)}</span>
        <span class="orig-price">$${deal.originalPrice.toFixed(2)}</span>
        <span class="dist-tag">📏 ${deal.distanceKm.toFixed(1)} km</span>
      </div>

      <div class="timer-box ${countdown.isUrgent ? 'urgent' : ''}" data-expiry="${deal.expiryTimestamp}">
        ⏳ ${countdown.text}
      </div>

      <div class="quota-bar-container">
        <div class="quota-text">
          <span>Claims: ${deal.claimedCount}/${deal.totalQuota}</span>
          <span>${deal.totalQuota - deal.claimedCount} remaining</span>
        </div>
        <div class="quota-bar">
          <div class="quota-fill" style="width: ${quotaPct}%"></div>
        </div>
      </div>

      <button class="btn btn-primary btn-block btn-claim" data-id="${deal.id}">
        🎟️ Claim Deal Voucher
      </button>
    `;

    card.querySelector('.btn-claim').addEventListener('click', () => claimDeal(deal));
    feed.appendChild(card);
  });
}

async function claimDeal(deal) {
  try {
    const res = await fetch(`/api/deals/${deal.id}/claim`, { method: 'POST' });
    const data = await res.json();
    if (res.ok) {
      if (typeof document !== 'undefined') {
        document.getElementById('modal-deal-title').innerText = data.dealTitle;
        document.getElementById('modal-merchant-name').innerText = `${data.merchant} • Claim ID: ${data.claimId}`;
        document.getElementById('modal-voucher-code').innerText = data.code;

        const shareUrl = `https://wa.me/?text=${encodeURIComponent(`Check out this flash deal on DealDrop! ${data.dealTitle} at ${data.merchant}. Use Voucher Code: ${data.code}`)}`;
        document.getElementById('btn-share-whatsapp').setAttribute('href', shareUrl);

        document.getElementById('voucher-modal').style.display = 'flex';
      }
      await fetchDeals();
      await fetchAnalytics();
    } else {
      alert('Claim failed: ' + data.error);
    }
  } catch (err) {
    alert('Network error claiming voucher');
  }
}

function startTimerLoop() {
  if (typeof document === 'undefined') return;
  setInterval(() => {
    document.querySelectorAll('.timer-box').forEach((box) => {
      const expiry = parseInt(box.getAttribute('data-expiry'), 10);
      if (expiry) {
        const cd = DealService.formatCountdown(expiry);
        box.innerText = `⏳ ${cd.text}`;
        box.classList.toggle('urgent', cd.isUrgent);
      }
    });
  }, 1000);
}

function initMap() {
  if (typeof leafletMap !== 'undefined' && leafletMap) return;
  if (typeof L === 'undefined' || typeof document === 'undefined') return;

  const mapContainer = document.getElementById('map-container');
  if (!mapContainer) return;

  leafletMap = L.map('map-container').setView([40.7128, -74.0060], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
  }).addTo(leafletMap);

  const coords = [
    [40.7128, -74.0060], [40.7150, -74.0090], [40.7110, -74.0030], [40.7180, -74.0120],
    [40.7200, -73.9980], [40.7090, -74.0150], [40.7250, -74.0010], [40.7140, -73.9950]
  ];

  allDeals.forEach((deal, idx) => {
    const loc = coords[idx % coords.length];
    const marker = L.marker(loc).addTo(leafletMap);
    marker.bindPopup(`
      <div style="font-family: sans-serif;">
        <strong style="color: #2563eb;">${deal.title}</strong><br>
        <span>🏪 ${deal.merchant} (${deal.discountPercent}% OFF)</span><br>
        <span>📍 ${deal.district} • ${deal.distanceKm} km away</span>
      </div>
    `);
    leafletMarkers.push(marker);
  });
}
