const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const config = require('./config');
const logger = require('./logger');
const { initDb, getDeals, claimVoucherAtomic, addDeal, getAnalytics } = require('./db');
const { authMiddleware, loginHandler } = require('./auth');
const { validateDealPayload } = require('./validator');

const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.yaml': 'text/yaml',
  '.md': 'text/markdown',
  '.png': 'image/png'
};

function parseJsonBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        resolve(null);
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // API Route Dispatcher
  if (pathname.startsWith('/api')) {
    res.setHeader('Content-Type', 'application/json');

    if (method === 'POST' && pathname === '/api/auth/login') {
      const body = await parseJsonBody(req);
      return loginHandler(req, res, body);
    }

    if (method === 'GET' && pathname === '/api/deals') {
      const deals = getDeals(parsedUrl.query.category, parsedUrl.query.radius, parsedUrl.query.happyHour);
      res.writeHead(200);
      return res.end(JSON.stringify(deals));
    }

    if (method === 'POST' && pathname.match(/^\/api\/deals\/[^\/]+\/claim$/)) {
      const dealId = pathname.split('/')[3];
      try {
        const result = await claimVoucherAtomic(dealId);
        logger.info(`Voucher claimed for deal ${dealId}`);
        res.writeHead(200);
        return res.end(JSON.stringify(result));
      } catch (err) {
        logger.warn(`Voucher claim failed for deal ${dealId}: ${err.message}`);
        res.writeHead(400);
        return res.end(JSON.stringify({ error: err.message }));
      }
    }

    if (method === 'GET' && pathname === '/api/analytics') {
      const analytics = getAnalytics();
      res.writeHead(200);
      return res.end(JSON.stringify(analytics));
    }

    if (method === 'POST' && pathname === '/api/deals') {
      return authMiddleware(req, res, async () => {
        const body = await parseJsonBody(req);
        if (!body) {
          res.writeHead(400);
          return res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
        }

        const validation = validateDealPayload(body);
        if (!validation.isValid) {
          logger.warn('Deal creation rejected: Invalid validation payload');
          res.writeHead(400);
          return res.end(JSON.stringify({ error: 'Validation failed', details: validation.errors }));
        }

        const newDeal = addDeal(validation.sanitized);
        logger.info(`Merchant created deal ${newDeal.id}: ${newDeal.title}`);
        res.writeHead(201);
        return res.end(JSON.stringify(newDeal));
      });
    }

    res.writeHead(404);
    return res.end(JSON.stringify({ error: 'Endpoint not found' }));
  }

  // Static File Serving
  let filePath = path.join(__dirname, pathname === '/' ? 'index.html' : pathname);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Server Error');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

if (process.env.NODE_ENV !== 'test') {
  initDb().then(() => {
    server.listen(config.port, () => {
      logger.info(`DealDrop v5 server running on port ${config.port} [${config.nodeEnv}]`);
    });
  });
}

module.exports = server;
