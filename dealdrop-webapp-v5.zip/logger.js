const fs = require('fs');
const path = require('path');
const config = require('./config');

const logFile = path.join(__dirname, 'server.log');

function formatLog(level, message, meta = '') {
  const timestamp = new Date().toISOString();
  const metaStr = meta ? ` | ${JSON.stringify(meta)}` : '';
  return `[${timestamp}] [${level.toUpperCase()}] ${message}${metaStr}\n`;
}

function writeLog(level, message, meta) {
  const line = formatLog(level, message, meta);
  if (config.nodeEnv !== 'test') {
    console.log(line.trim());
  }
  try {
    fs.appendFileSync(logFile, line, 'utf8');
  } catch (err) {
    // Fallback if write fails
  }
}

module.exports = {
  info: (msg, meta) => writeLog('info', msg, meta),
  warn: (msg, meta) => writeLog('warn', msg, meta),
  error: (msg, meta) => writeLog('error', msg, meta)
};
