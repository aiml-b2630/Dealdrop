function sanitizeInput(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[<>&"']/g, (c) => {
    return { '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

const ALLOWED_CATEGORIES = ['Dining', 'Wellness', 'Fitness', 'Entertainment', 'Services'];

function validateDealPayload(body) {
  const errors = [];
  const { title, merchant, category, district, discountPercent, originalPrice, dealPrice, distanceKm, totalQuota, expiryHours, code } = body;

  if (!title || typeof title !== 'string' || title.trim().length < 3) {
    errors.push('Title must be a string of at least 3 characters.');
  }
  if (!merchant || typeof merchant !== 'string' || merchant.trim().length < 2) {
    errors.push('Merchant name must be a string of at least 2 characters.');
  }
  if (!category || !ALLOWED_CATEGORIES.includes(category)) {
    errors.push(`Category must be one of: ${ALLOWED_CATEGORIES.join(', ')}.`);
  }
  if (!district || typeof district !== 'string') {
    errors.push('District must be specified.');
  }
  if (typeof discountPercent !== 'number' || discountPercent <= 0 || discountPercent > 100) {
    errors.push('Discount percent must be a number between 1 and 100.');
  }
  if (typeof originalPrice !== 'number' || originalPrice <= 0) {
    errors.push('Original price must be a positive number.');
  }
  if (typeof dealPrice !== 'number' || dealPrice < 0 || dealPrice >= originalPrice) {
    errors.push('Deal price must be less than original price.');
  }
  if (typeof distanceKm !== 'number' || distanceKm <= 0) {
    errors.push('Distance in Km must be a positive number.');
  }
  if (!Number.isInteger(totalQuota) || totalQuota <= 0) {
    errors.push('Total quota must be a positive integer.');
  }
  if (!Number.isInteger(expiryHours) || expiryHours <= 0) {
    errors.push('Expiry hours must be a positive integer.');
  }
  if (!code || typeof code !== 'string' || code.trim().length < 3) {
    errors.push('Voucher code must be at least 3 characters.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: errors.length === 0 ? {
      title: sanitizeInput(title.trim()),
      merchant: sanitizeInput(merchant.trim()),
      category,
      district: sanitizeInput(district.trim()),
      discountPercent: Number(discountPercent),
      originalPrice: Number(originalPrice),
      dealPrice: Number(dealPrice),
      distanceKm: Number(distanceKm),
      totalQuota: Number(totalQuota),
      expiryHours: Number(expiryHours),
      code: sanitizeInput(code.trim().toUpperCase())
    } : null
  };
}

module.exports = {
  sanitizeInput,
  validateDealPayload
};
