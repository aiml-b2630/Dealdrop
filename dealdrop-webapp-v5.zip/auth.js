const crypto = require('crypto');
const config = require('./config');
const logger = require('./logger');

const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'password123'
};

function base64UrlEncode(str) {
  return Buffer.from(str).toString('base64url');
}

function base64UrlDecode(str) {
  return Buffer.from(str, 'base64url').toString('utf8');
}

function signJwt(payload, secret) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const signature = crypto
    .createHmac('sha256', secret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

function verifyJwt(token, secret) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [encodedHeader, encodedPayload, signature] = parts;

    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(`${encodedHeader}.${encodedPayload}`)
      .digest('base64url');

    if (signature !== expectedSignature) return null;

    const payload = JSON.parse(base64UrlDecode(encodedPayload));
    if (payload.exp && Date.now() >= payload.exp * 1000) return null;

    return payload;
  } catch (err) {
    return null;
  }
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    logger.warn('Unauthorized API access attempt: Missing token');
    res.writeHead(401, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'Unauthorized: Missing Authorization header' }));
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'Unauthorized: Malformed Authorization header' }));
  }

  const decoded = verifyJwt(token, config.jwtSecret);
  if (!decoded) {
    logger.warn('Unauthorized API access attempt: Invalid token signature');
    res.writeHead(403, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'Forbidden: Invalid or expired token' }));
  }

  req.user = decoded;
  next();
}

function loginHandler(req, res, body) {
  const { username, password } = body || {};
  if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
    const exp = Math.floor(Date.now() / 1000) + 28800; // 8 hours
    const token = signJwt({ username: ADMIN_CREDENTIALS.username, role: 'merchant', exp }, config.jwtSecret);
    logger.info(`Merchant ${username} logged in successfully.`);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ token, username, role: 'merchant' }));
  }
  logger.warn(`Failed login attempt for username: ${username}`);
  res.writeHead(401, { 'Content-Type': 'application/json' });
  return res.end(JSON.stringify({ error: 'Invalid merchant credentials' }));
}

module.exports = {
  signJwt,
  verifyJwt,
  authMiddleware,
  loginHandler
};
