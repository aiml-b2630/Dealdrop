# DealDrop REST API Documentation (v5.0)

Welcome to the **DealDrop REST API** reference documentation. The DealDrop API provides endpoints for searching hyperlocal promotional deals, atomically claiming discount vouchers, authenticating merchants, and retrieving live campaign analytics.

---

## Base URL
`http://localhost:3000/api`

---

## Authentication
Merchant routes require a **JSON Web Token (JWT)** passed in the `Authorization` header:
`Authorization: Bearer <your_jwt_token>`

---

## Endpoints Summary

### 1. Merchant Authentication
* **POST `/api/auth/login`**
  * **Description**: Authenticate merchant credentials (`admin` / `password123`) to receive a JWT access token.
  * **Request Payload**:
    ```json
    {
      "username": "admin",
      "password": "password123"
    }
    ```
  * **Response (200 OK)**:
    ```json
    {
      "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "username": "admin",
      "role": "merchant"
    }
    ```

### 2. Hyperlocal Deals Discovery
* **GET `/api/deals`**
  * **Query Parameters**:
    * `category` (string, optional): `Dining`, `Wellness`, `Fitness`, `Entertainment`, `Services`
    * `radius` (number, optional): Max distance in km (e.g., `1.0`, `3.0`, `5.0`)
    * `happyHour` (boolean, optional): Filter offers with >= 40% discount (`true`)
  * **Response (200 OK)**:
    ```json
    [
      {
        "id": "d1",
        "title": "40% Off Artisan Coffee & Pastry",
        "merchant": "Artisan Cafe",
        "category": "Dining",
        "district": "Downtown Core",
        "discountPercent": 40,
        "originalPrice": 15.00,
        "dealPrice": 9.00,
        "distanceKm": 0.8,
        "expiryTimestamp": 1774000000000,
        "totalQuota": 25,
        "claimedCount": 12,
        "code": "PASTRY40",
        "isHappyHour": 1
      }
    ]
    ```

### 3. Atomic Voucher Claiming
* **POST `/api/deals/:id/claim`**
  * **Description**: Atomically claims a voucher, decrements remaining allowance using SQLite transactions, and generates a 2-hour anti-hoarding claim token.
  * **Response (200 OK)**:
    ```json
    {
      "claimId": "clm_a9b8c7d6e",
      "dealId": "d1",
      "code": "PASTRY40",
      "remainingQuota": 12,
      "expiresAt": 1774007200000,
      "dealTitle": "40% Off Artisan Coffee & Pastry",
      "merchant": "Artisan Cafe"
    }
    ```

### 4. Publish Flash Deal (Protected)
* **POST `/api/deals`**
  * **Headers**: `Authorization: Bearer <token>`
  * **Request Payload**:
    ```json
    {
      "title": "50% Off Evening Pizza Slice Combo",
      "merchant": "Bella Italia",
      "category": "Dining",
      "district": "Northside Plaza",
      "discountPercent": 50,
      "originalPrice": 20.00,
      "dealPrice": 10.00,
      "distanceKm": 1.5,
      "totalQuota": 20,
      "expiryHours": 3,
      "code": "PIZZA50"
    }
    ```

### 5. Campaign Analytics
* **GET `/api/analytics`**
  * **Response (200 OK)**:
    ```json
    {
      "totalViews": 1421,
      "totalClaims": 319,
      "conversionRate": "22.4%",
      "estimatedWalkIns": 271,
      "totalSavings": "$4856.00"
    }
    ```
