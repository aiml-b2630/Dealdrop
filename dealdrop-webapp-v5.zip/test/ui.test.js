// Frontend UI Component DOM Test Suite (v5.0)
const { DealService } = require('../app.js');

function runUiTests() {
  console.log('==========================================');
  console.log(' Running Frontend UI Component DOM Tests ');
  console.log('==========================================');

  // Test 1: DOM Deal Card Formatting Heuristics
  const deal = {
    id: 'd_test',
    title: '50% Off Gourmet Lunch',
    merchant: 'Test Bistro',
    category: 'Dining',
    district: 'Downtown Core',
    discountPercent: 50,
    originalPrice: 20.00,
    dealPrice: 10.00,
    distanceKm: 0.5,
    expiryTimestamp: Date.now() + 3600000,
    totalQuota: 10,
    claimedCount: 4,
    code: 'LUNCH50',
    isHappyHour: 1
  };

  const isHH = deal.discountPercent >= 40 || deal.isHappyHour === 1;
  console.assert(isHH === true, 'UI Test 1 Failed: Happy Hour Badge Detection');
  console.log('UI Test 1: Happy Hour Badge Detection... ✅ Passed!');

  // Test 2: Quota Progress Fill Percentage Calculation
  const fillPct = Math.min(100, Math.round((deal.claimedCount / deal.totalQuota) * 100));
  console.assert(fillPct === 40, 'UI Test 2 Failed: Quota Progress Fill Percentage');
  console.log('UI Test 2: Quota Fill Calculation (40%)... ✅ Passed!');

  // Test 3: Search Query String Sanitization & Matching
  const match = DealService.filterDeals([deal], 'All', 5.0, 'All', false, 'bistro');
  console.assert(match.length === 1, 'UI Test 3 Failed: Search Input Filter Matching');
  console.log('UI Test 3: Search Input Filter Matching... ✅ Passed!');

  console.log('------------------------------------------');
  console.log('All UI DOM Component Tests Executed Successfully! 🚀\n');
}

if (require.main === module) {
  runUiTests();
}

module.exports = { runUiTests };
