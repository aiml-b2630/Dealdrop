// REST API Integration Test Suite (v5.0)
process.env.NODE_ENV = 'test';

const http = require('http');
const server = require('../server.js');
const { initDb } = require('../db.js');

const PORT = 3002;

function makeRequest(method, path, headers = {}, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(`http://localhost:${PORT}${path}`, { method, headers }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = data ? JSON.parse(data) : {};
          resolve({ status: res.statusCode, body: json });
        } catch (e) {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runApiTests() {
  console.log('==========================================');
  console.log(' Running REST API Integration Tests      ');
  console.log('==========================================');

  await initDb();
  await new Promise(r => server.listen(PORT, r));

  try {
    // 1. GET /api/deals
    const resDeals = await makeRequest('GET', '/api/deals');
    console.assert(resDeals.status === 200 && Array.isArray(resDeals.body), 'API Test 1 Failed: GET /api/deals');
    console.log('API Test 1: GET /api/deals... ✅ Passed!');

    // 2. POST /api/auth/login (Success)
    const resAuth = await makeRequest('POST', '/api/auth/login', { 'Content-Type': 'application/json' }, { username: 'admin', password: 'password123' });
    console.assert(resAuth.status === 200 && resAuth.body.token, 'API Test 2 Failed: Auth Login');
    console.log('API Test 2: POST /api/auth/login... ✅ Passed!');
    const jwtToken = resAuth.body.token;

    // 3. POST /api/deals (Unauthorized Rejection 401)
    const resUnauth = await makeRequest('POST', '/api/deals', { 'Content-Type': 'application/json' }, { title: 'Test' });
    console.assert(resUnauth.status === 401, 'API Test 3 Failed: Unauthorized Rejection');
    console.log('API Test 3: 401 Unauthorized Rejection... ✅ Passed!');

    // 4. POST /api/deals (Malformed Payload Rejection 400)
    const resBad = await makeRequest('POST', '/api/deals', { 'Content-Type': 'application/json', 'Authorization': `Bearer ${jwtToken}` }, { title: 'X' });
    console.assert(resBad.status === 400, 'API Test 4 Failed: Payload Validation');
    console.log('API Test 4: 400 Malformed Payload Rejection... ✅ Passed!');

    // 5. POST /api/deals/:id/claim (Atomic Voucher Claim)
    const dealId = resDeals.body[0].id;
    const resClaim = await makeRequest('POST', `/api/deals/${dealId}/claim`);
    console.assert(resClaim.status === 200 && resClaim.body.claimId, 'API Test 5 Failed: Atomic Voucher Claim');
    console.log('API Test 5: Atomic Voucher Claim... ✅ Passed!');

    // 6. GET /api/analytics
    const resAnalytics = await makeRequest('GET', '/api/analytics');
    console.assert(resAnalytics.status === 200 && resAnalytics.body.totalViews !== undefined, 'API Test 6 Failed: GET /api/analytics');
    console.log('API Test 6: GET /api/analytics... ✅ Passed!');

    console.log('------------------------------------------');
    console.log('All REST API Integration Tests Passed! 🚀\\n');
  } finally {
    server.close();
  }
}

if (require.main === module) {
  runApiTests().catch(err => {
    console.error('API Test Error:', err);
    process.exit(1);
  });
}

module.exports = { runApiTests };
