// Deal Engine Unit Tests (v5.0)
const { DealService } = require('../app.js');

function runUnitTests() {
  console.log('==========================================');
  console.log(' Running Deal Engine Unit Tests (v5.0)   ');
  console.log('==========================================');

  const mockDeals = [
    { id: '1', title: 'Coffee Deal', merchant: 'Cafe A', category: 'Dining', district: 'Downtown Core', discountPercent: 40, originalPrice: 10, dealPrice: 6, distanceKm: 0.8, expiryTimestamp: Date.now() + 3600000, totalQuota: 10, claimedCount: 2, code: 'CAFE40', isHappyHour: 1 },
    { id: '2', title: 'Gym Pass', merchant: 'Fit B', category: 'Fitness', district: 'Westend Heights', discountPercent: 20, originalPrice: 50, dealPrice: 40, distanceKm: 2.5, expiryTimestamp: Date.now() + 7200000, totalQuota: 5, claimedCount: 1, code: 'GYM20', isHappyHour: 0 },
    { id: '3', title: 'Spa Massage', merchant: 'Spa C', category: 'Wellness', district: 'Eastside District', discountPercent: 50, originalPrice: 100, dealPrice: 50, distanceKm: 4.2, expiryTimestamp: Date.now() + 5400000, totalQuota: 8, claimedCount: 8, code: 'SPA50', isHappyHour: 1 }
  ];

  // Test 1: Category Filtering
  const diningDeals = DealService.filterDeals(mockDeals, 'Dining', 5.0);
  console.assert(diningDeals.length === 1 && diningDeals[0].id === '1', 'Test 1 Failed: Category Filtering');
  console.log('Test 1: Category Filtering... ✅ Passed!');

  // Test 2: Distance Radius Filtering
  const nearDeals = DealService.filterDeals(mockDeals, 'All', 1.0);
  console.assert(nearDeals.length === 1 && nearDeals[0].id === '1', 'Test 2 Failed: Distance Radius Filtering');
  console.log('Test 2: Distance Radius Filtering... ✅ Passed!');

  // Test 3: Happy Hour Auto-Trigger Filter
  const hhDeals = DealService.filterDeals(mockDeals, 'All', 5.0, 'All', true);
  console.assert(hhDeals.length === 2, 'Test 3 Failed: Happy Hour Auto-Trigger Filter');
  console.log('Test 3: Happy Hour Filter... ✅ Passed!');

  // Test 4: Countdown Urgency Timer
  const cd = DealService.formatCountdown(Date.now() + 1800000); // 30 mins remaining
  console.assert(cd.isUrgent === true && cd.text.includes('Ends in 0h 30m'), 'Test 4 Failed: Countdown Urgency Timer');
  console.log('Test 4: Countdown Urgency Timer... ✅ Passed!');

  console.log('------------------------------------------');
  console.log('All 4 Unit Test Cases Executed Successfully! 🚀\n');
}

if (require.main === module) {
  runUnitTests();
}

module.exports = { runUnitTests };
