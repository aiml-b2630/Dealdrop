const crypto = require('crypto');

const SECRET = 'dealdrop-hackathon-jwt-secret-2026';

function generateToken(payload) {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + (8 * 3600 * 1000) })).toString('base64url');
    const signature = crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest('base64url');
    return `${header}.${body}.${signature}`;
}

function verifyToken(token) {
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest('base64url');
    if (signature !== expectedSig) return null;
    try {
        const decoded = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
        if (decoded.exp < Date.now()) return null;
        return decoded;
    } catch (e) {
        return null;
    }
}

function authMiddleware(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ success: false, error: 'Unauthorized: Merchant authentication required' });
    }
    const token = authHeader.split(' ')[1];
    const user = verifyToken(token);
    if (!user) {
        return res.status(403).json({ success: false, error: 'Forbidden: Invalid or expired JWT token' });
    }
    req.user = user;
    next();
}

module.exports = { generateToken, verifyToken, authMiddleware };
