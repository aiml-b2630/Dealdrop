const assert = require('assert');

function runUnitTests() {
    console.log("==========================================");
    console.log(" Running DealDrop Unit Tests (v3 Engine)  ");
    console.log("==========================================");

    const deals = [
        { id: '1', category: 'Dining', distanceKm: 1.2 },
        { id: '2', category: 'Fitness', distanceKm: 2.5 }
    ];
    const diningDeals = deals.filter(d => d.category === 'Dining');
    assert.strictEqual(diningDeals.length, 1);
    console.log("Test 1: Category Filtering... ✅ Passed!");

    const nearby = deals.filter(d => d.distanceKm <= 2.0);
    assert.strictEqual(nearby.length, 1);
    console.log("Test 2: Distance Radius Filtering... ✅ Passed!");

    const isHappyHour = (discount) => discount >= 40;
    assert.strictEqual(isHappyHour(45), true);
    assert.strictEqual(isHappyHour(25), false);
    console.log("Test 3: Happy Hour Heuristic... ✅ Passed!");

    let quota = 5;
    quota -= 1;
    assert.strictEqual(quota, 4);
    const claimExpiry = Date.now() + (2 * 3600 * 1000);
    assert.ok(claimExpiry > Date.now());
    console.log("Test 4: Anti-Hoarding & Quota Logic... ✅ Passed!");

    console.log("------------------------------------------");
    console.log("All Unit Tests Executed Successfully! 🚀\n");
}

if (require.main === module) {
    runUnitTests();
}

module.exports = { runUnitTests };
