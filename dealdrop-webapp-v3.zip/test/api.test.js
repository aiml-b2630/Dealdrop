const assert = require('assert');
const app = require('../server');
const http = require('http');

let server;

function runApiTests() {
    console.log("==========================================");
    console.log(" Running DealDrop Express API Integration Tests ");
    console.log("==========================================");

    server = app.listen(3001, () => {
        http.get('http://localhost:3001/api/deals', (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                const json = JSON.parse(data);
                assert.strictEqual(res.statusCode, 200);
                assert.strictEqual(json.success, true);
                assert.ok(Array.isArray(json.deals));
                console.log("API Test 1: GET /api/deals Endpoint... ✅ Passed!");

                http.get('http://localhost:3001/api/analytics', (res2) => {
                    let data2 = '';
                    res2.on('data', chunk => data2 += chunk);
                    res2.on('end', () => {
                        const json2 = JSON.parse(data2);
                        assert.strictEqual(res2.statusCode, 200);
                        assert.strictEqual(json2.success, true);
                        assert.ok(json2.totalViews !== undefined);
                        console.log("API Test 2: GET /api/analytics Endpoint... ✅ Passed!");

                        server.close(() => {
                            console.log("------------------------------------------");
                            console.log("All API Integration Tests Passed! 🚀\n");
                            process.exit(0);
                        });
                    });
                });
            });
        });
    });
}

if (require.main === module) {
    runApiTests();
}
