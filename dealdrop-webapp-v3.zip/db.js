const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = path.join(__dirname, 'dealdrop.db');
const db = new sqlite3.Database(DB_PATH);

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS deals (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        merchant TEXT NOT NULL,
        category TEXT NOT NULL,
        discount INTEGER NOT NULL,
        originalPrice REAL NOT NULL,
        discountedPrice REAL NOT NULL,
        distanceKm REAL NOT NULL,
        district TEXT NOT NULL,
        expiresAt INTEGER NOT NULL,
        quotaTotal INTEGER NOT NULL,
        quotaRemaining INTEGER NOT NULL,
        code TEXT NOT NULL,
        happyHour INTEGER DEFAULT 0,
        createdAt INTEGER NOT NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS claims (
        claimId TEXT PRIMARY KEY,
        dealId TEXT NOT NULL,
        voucherCode TEXT NOT NULL,
        claimedAt INTEGER NOT NULL,
        expiresAt INTEGER NOT NULL,
        status TEXT DEFAULT 'active'
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS merchants (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        passwordHash TEXT NOT NULL,
        businessName TEXT NOT NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS analytics_summary (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        totalViews INTEGER DEFAULT 0,
        totalClaims INTEGER DEFAULT 0,
        estimatedWalkIns INTEGER DEFAULT 0,
        totalSavings REAL DEFAULT 0.0
    )`);

    db.run(`INSERT OR IGNORE INTO analytics_summary (id, totalViews, totalClaims, estimatedWalkIns, totalSavings) VALUES (1, 1420, 318, 270, 45200.0)`);
});

module.exports = db;
