const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');
const logger = require('./logger');
const { generateToken, authMiddleware } = require('./auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const dealsData = require('./deals.json');
db.serialize(() => {
    db.get('SELECT COUNT(*) as count FROM deals', (err, row) => {
        if (row && row.count === 0) {
            logger.info('Seeding SQLite database with default deals...');
            const stmt = db.prepare(`INSERT INTO deals (id, title, merchant, category, discount, originalPrice, discountedPrice, distanceKm, district, expiresAt, quotaTotal, quotaRemaining, code, happyHour, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
            const now = Date.now();
            dealsData.forEach(d => {
                stmt.run(d.id, d.title, d.merchant, d.category, d.discount, d.originalPrice, d.discountedPrice, d.distanceKm, d.district, now + (d.hoursRemaining * 3600 * 1000), d.quotaTotal, d.quotaRemaining, d.code, d.discount >= 40 ? 1 : 0, now);
            });
            stmt.finalize();
        }
    });

    db.run(`INSERT OR IGNORE INTO merchants (id, username, passwordHash, businessName) VALUES ('m1', 'admin', 'password123', 'Artisan Bakery & Cafe')`);
});

function sanitizeInput(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/[<>'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}

app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    db.get('SELECT * FROM merchants WHERE username = ? AND passwordHash = ?', [username, password], (err, merchant) => {
        if (err || !merchant) {
            logger.warn('Failed merchant login attempt', { username });
            return res.status(401).json({ success: false, error: 'Invalid merchant credentials' });
        }
        const token = generateToken({ id: merchant.id, username: merchant.username, businessName: merchant.businessName });
        logger.info('Merchant logged in successfully', { username: merchant.username });
        res.json({ success: true, token, businessName: merchant.businessName });
    });
});

app.get('/api/deals', (req, res) => {
    const { category, maxDistance } = req.query;
    let query = 'SELECT * FROM deals WHERE expiresAt > ?';
    let params = [Date.now()];

    if (category && category !== 'All') {
        query += ' AND category = ?';
        params.push(category);
    }
    if (maxDistance) {
        query += ' AND distanceKm <= ?';
        params.push(parseFloat(maxDistance));
    }
    query += ' ORDER BY createdAt DESC';

    db.all(query, params, (err, rows) => {
        if (err) {
            logger.error('Error fetching deals', { error: err.message });
            return res.status(500).json({ success: false, error: 'Database error' });
        }
        db.run('UPDATE analytics_summary SET totalViews = totalViews + ? WHERE id = 1', [rows.length]);
        res.json({ success: true, count: rows.length, deals: rows });
    });
});

app.post('/api/deals/:id/claim', (req, res) => {
    const dealId = req.params.id;
    db.get('SELECT * FROM deals WHERE id = ?', [dealId], (err, deal) => {
        if (err || !deal) {
            return res.status(404).json({ success: false, error: 'Deal not found' });
        }
        if (deal.quotaRemaining <= 0) {
            return res.status(400).json({ success: false, error: 'Voucher quota exhausted' });
        }
        if (deal.expiresAt <= Date.now()) {
            return res.status(400).json({ success: false, error: 'Deal has expired' });
        }

        const now = Date.now();
        const claimExpiry = now + (2 * 3600 * 1000);
        const claimId = `claim_${now}_${Math.random().toString(36).substring(2, 6)}`;
        const voucherCode = `${deal.code}-${Math.floor(1000 + Math.random() * 9000)}`;
        const savings = deal.originalPrice - deal.discountedPrice;

        db.serialize(() => {
            db.run('UPDATE deals SET quotaRemaining = quotaRemaining - 1 WHERE id = ?', [dealId]);
            db.run('INSERT INTO claims (claimId, dealId, voucherCode, claimedAt, expiresAt) VALUES (?, ?, ?, ?, ?)', [claimId, dealId, voucherCode, now, claimExpiry]);
            db.run('UPDATE analytics_summary SET totalClaims = totalClaims + 1, estimatedWalkIns = estimatedWalkIns + 1, totalSavings = totalSavings + ? WHERE id = 1', [savings]);
        });

        logger.info('Voucher claimed successfully', { dealId, voucherCode });
        res.json({
            success: true,
            claimId,
            voucherCode,
            expiresAt: claimExpiry,
            quotaRemaining: deal.quotaRemaining - 1,
            message: 'Voucher claimed! Complete redemption within 2 hours.'
        });
    });
});

app.post('/api/deals', authMiddleware, (req, res) => {
    const { title, category, discount, originalPrice, distanceKm, district, hoursRemaining, quotaTotal, code } = req.body;
    
    if (!title || !category || !discount || !originalPrice || !quotaTotal || !code) {
        return res.status(400).json({ success: false, error: 'Missing required deal parameters' });
    }

    const cleanTitle = sanitizeInput(title);
    const cleanCode = sanitizeInput(code).toUpperCase();
    const dealId = `deal_${Date.now()}`;
    const disc = parseInt(discount);
    const orig = parseFloat(originalPrice);
    const discountedPrice = Math.round(orig * (1 - disc / 100));
    const now = Date.now();
    const expiresAt = now + (parseFloat(hoursRemaining || 3) * 3600 * 1000);
    const merchantName = req.user.businessName || 'Verified Merchant';

    const stmt = db.prepare(`INSERT INTO deals (id, title, merchant, category, discount, originalPrice, discountedPrice, distanceKm, district, expiresAt, quotaTotal, quotaRemaining, code, happyHour, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    stmt.run(dealId, cleanTitle, merchantName, category, disc, orig, discountedPrice, parseFloat(distanceKm || 1.5), district || 'Central', expiresAt, parseInt(quotaTotal), parseInt(quotaTotal), cleanCode, disc >= 40 ? 1 : 0, now, function(err) {
        if (err) {
            logger.error('Failed to create deal', { error: err.message });
            return res.status(500).json({ success: false, error: 'Failed to create deal in persistent store' });
        }
        logger.info('Merchant published new flash deal', { dealId, title: cleanTitle });
        res.status(201).json({ success: true, dealId, message: 'Flash deal published successfully to neighborhood feed!' });
    });
});

app.get('/api/analytics', (req, res) => {
    db.get('SELECT * FROM analytics_summary WHERE id = 1', (err, summary) => {
        if (err || !summary) {
            return res.status(500).json({ success: false, error: 'Analytics error' });
        }
        const conversionRate = summary.totalViews > 0 ? ((summary.totalClaims / summary.totalViews) * 100).toFixed(1) : 0;
        res.json({
            success: true,
            totalViews: summary.totalViews,
            totalClaims: summary.totalClaims,
            estimatedWalkIns: summary.estimatedWalkIns,
            totalSavings: summary.totalSavings,
            conversionRate: `${conversionRate}%`
        });
    });
});

app.use((err, req, res, next) => {
    logger.error('Unhandled Server Error', { error: err.message, stack: err.stack });
    res.status(500).json({ success: false, error: 'Internal Server Error' });
});

if (require.main === module) {
    app.listen(PORT, () => {
        logger.info(`DealDrop API Server v3 running on http://localhost:${PORT}`);
    });
}

module.exports = app;
