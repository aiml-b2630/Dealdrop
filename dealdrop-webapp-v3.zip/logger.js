const fs = require('fs');
const path = require('path');

const LOG_FILE = path.join(__dirname, 'server.log');

function log(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const logEntry = JSON.stringify({ timestamp, level, message, ...meta });
    console.log(`[${timestamp}] [${level.toUpperCase()}]: ${message}`, Object.keys(meta).length ? meta : '');
    fs.appendFileSync(LOG_FILE, logEntry + '\n');
}

module.exports = {
    info: (msg, meta) => log('info', msg, meta),
    warn: (msg, meta) => log('warn', msg, meta),
    error: (msg, meta) => log('error', msg, meta)
};
