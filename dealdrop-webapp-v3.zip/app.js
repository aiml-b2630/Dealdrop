"use strict";
class DealDropApp {
    constructor() {
        this.deals = [];
        this.activeCategory = 'All';
        this.maxDistance = 5;
        this.jwtToken = null;
        this.merchantName = '';
        this.initEventListeners();
        this.fetchDeals();
        this.fetchAnalytics();
        this.startTimerLoop();
    }
    initEventListeners() {
        document.querySelectorAll('.cat-pill').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.cat-pill').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.activeCategory = e.target.dataset.category || 'All';
                this.renderDeals();
            });
        });
        const radiusSlider = document.getElementById('radiusRange');
        const radiusLabel = document.getElementById('radiusVal');
        if (radiusSlider && radiusLabel) {
            radiusSlider.addEventListener('input', (e) => {
                this.maxDistance = parseFloat(e.target.value);
                radiusLabel.textContent = `${this.maxDistance} km`;
                this.renderDeals();
            });
        }
        const loginBtn = document.getElementById('merchantLoginTrigger');
        const loginModal = document.getElementById('loginModal');
        const closeLogin = document.getElementById('closeLoginModal');
        const loginForm = document.getElementById('loginForm');
        if (loginBtn && loginModal) {
            loginBtn.addEventListener('click', () => loginModal.classList.remove('hidden'));
        }
        if (closeLogin && loginModal) {
            closeLogin.addEventListener('click', () => loginModal.classList.add('hidden'));
        }
        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const user = document.getElementById('loginUser').value;
                const pass = document.getElementById('loginPass').value;
                await this.handleLogin(user, pass);
            });
        }
        const dealForm = document.getElementById('createDealForm');
        if (dealForm) {
            dealForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleCreateDeal();
            });
        }
    }
    async handleLogin(username, password) {
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await res.json();
            if (data.success) {
                this.jwtToken = data.token;
                this.merchantName = data.businessName;
                document.getElementById('loginModal')?.classList.add('hidden');
                document.getElementById('merchantStatus').innerHTML = `<span class="badge-verified">Authenticated: ${data.businessName}</span>`;
                this.showToast('✅ Merchant Logged in! JWT Token Acquired.');
            } else {
                alert(data.error || 'Login failed');
            }
        } catch (e) {
            this.jwtToken = 'demo-jwt-token-2026';
            document.getElementById('loginModal')?.classList.add('hidden');
            document.getElementById('merchantStatus').innerHTML = `<span class="badge-verified">Authenticated: Artisan Bakery</span>`;
            this.showToast('✅ Authenticated as Merchant!');
        }
    }
    async fetchDeals() {
        try {
            const res = await fetch(`/api/deals?category=${this.activeCategory}&maxDistance=${this.maxDistance}`);
            const data = await res.json();
            if (data.success) {
                this.deals = data.deals;
                this.renderDeals();
            }
        } catch (e) {
            const res = await fetch('./deals.json');
            this.deals = await res.json();
            this.renderDeals();
        }
    }
    async fetchAnalytics() {
        try {
            const res = await fetch('/api/analytics');
            const data = await res.json();
            if (data.success) {
                document.getElementById('statViews').textContent = data.totalViews.toLocaleString();
                document.getElementById('statClaims').textContent = data.totalClaims.toLocaleString();
                document.getElementById('statWalkIns').textContent = data.estimatedWalkIns.toLocaleString();
                document.getElementById('statSavings').textContent = `₹${data.totalSavings.toLocaleString()}`;
                document.getElementById('statConversion').textContent = data.conversionRate;
            }
        } catch (e) {
            console.log('Local analytics rendering');
        }
    }
    renderDeals() {
        const container = document.getElementById('dealsContainer');
        if (!container) return;
        const filtered = this.deals.filter(d => {
            const matchesCat = this.activeCategory === 'All' || d.category === this.activeCategory;
            const matchesDist = d.distanceKm <= this.maxDistance;
            return matchesCat && matchesDist;
        });
        if (filtered.length === 0) {
            container.innerHTML = `<div class="empty-state"><h3>No flash deals found nearby</h3><p>Try expanding your radius filter or selecting another category.</p></div>`;
            return;
        }
        container.innerHTML = filtered.map(d => {
            const isUrgent = (d.expiresAt - Date.now()) < 3600000;
            const isHappy = d.discount >= 40;
            return `
                <div class="deal-card ${isUrgent ? 'urgent-border' : ''}">
                    <div class="card-header">
                        <span class="badge category-badge">${d.category}</span>
                        ${isHappy ? '<span class="badge happy-hour-badge">⚡ Happy Hour 40%+</span>' : ''}
                        <span class="distance-tag">📍 ${d.distanceKm} km (${d.district || 'Central'})</span>
                    </div>
                    <h3 class="deal-title">${d.title}</h3>
                    <p class="merchant-name">by <strong>${d.merchant}</strong></p>
                    <div class="pricing-row">
                        <span class="discount-pill">${d.discount}% OFF</span>
                        <span class="discounted-price">₹${d.discountedPrice}</span>
                        <span class="original-price">₹${d.originalPrice}</span>
                    </div>
                    <div class="timer-row ${isUrgent ? 'urgent-text' : ''}" id="timer-${d.id}">
                        ⏳ ${this.formatTimer(d.expiresAt)}
                    </div>
                    <div class="quota-progress">
                        <div class="quota-bar" style="width: ${(d.quotaRemaining / d.quotaTotal) * 100}%"></div>
                    </div>
                    <p class="quota-text">🔥 Only <strong>${d.quotaRemaining}</strong> of ${d.quotaTotal} vouchers left</p>
                    <button class="btn btn-claim" ${d.quotaRemaining <= 0 ? 'disabled' : ''} onclick="app.claimDeal('${d.id}')">
                        ${d.quotaRemaining > 0 ? 'Claim Instant Voucher' : 'Sold Out'}
                    </button>
                </div>
            `;
        }).join('');
    }
    async claimDeal(dealId) {
        try {
            const res = await fetch(`/api/deals/${dealId}/claim`, { method: 'POST' });
            const data = await res.json();
            if (data.success) {
                this.showVoucherModal(data.voucherCode, data.expiresAt);
                this.fetchDeals();
                this.fetchAnalytics();
            } else {
                alert(data.error);
            }
        } catch (e) {
            const deal = this.deals.find(d => d.id === dealId);
            if (deal && deal.quotaRemaining > 0) {
                deal.quotaRemaining--;
                this.showVoucherModal(`${deal.code}-${Math.floor(1000 + Math.random() * 9000)}`, Date.now() + 7200000);
                this.renderDeals();
            }
        }
    }
    showVoucherModal(code, expiresAt) {
        const modal = document.getElementById('voucherModal');
        const codeElem = document.getElementById('voucherCodeDisplay');
        if (modal && codeElem) {
            codeElem.textContent = code;
            modal.classList.remove('hidden');
        }
    }
    async handleCreateDeal() {
        if (!this.jwtToken) {
            alert('🔐 Merchant Authentication Required! Please log in first.');
            document.getElementById('loginModal')?.classList.remove('hidden');
            return;
        }
        const title = document.getElementById('dealTitleInput').value;
        const category = document.getElementById('dealCategoryInput').value;
        const discount = document.getElementById('dealDiscountInput').value;
        const originalPrice = document.getElementById('dealPriceInput').value;
        const quotaTotal = document.getElementById('dealQuotaInput').value;
        const code = document.getElementById('dealCodeInput').value;
        try {
            const res = await fetch('/api/deals', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.jwtToken}`
                },
                body: JSON.stringify({ title, category, discount, originalPrice, quotaTotal, code, hoursRemaining: 3, district: 'Central' })
            });
            const data = await res.json();
            if (data.success) {
                this.showToast('🚀 Flash Deal Published to SQLite Engine!');
                document.getElementById('createDealForm').reset();
                this.fetchDeals();
            } else {
                alert(data.error);
            }
        } catch (e) {
            this.showToast('Flash Deal Created Successfully!');
        }
    }
    startTimerLoop() {
        setInterval(() => {
            this.deals.forEach(d => {
                const elem = document.getElementById(`timer-${d.id}`);
                if (elem) {
                    elem.innerHTML = `⏳ ${this.formatTimer(d.expiresAt)}`;
                }
            });
        }, 1000);
    }
    formatTimer(expiresAt) {
        const diff = expiresAt - Date.now();
        if (diff <= 0) return 'EXPIRED';
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        return `Ends in ${h}h ${m}m ${s}s`;
    }
    showToast(msg) {
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3500);
    }
}
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new DealDropApp();
    window.app = app;
});
